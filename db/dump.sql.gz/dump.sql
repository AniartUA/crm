--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: mediatypes; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE mediatypes AS ENUM (
    'phone',
    'messenger',
    'email'
);


ALTER TYPE public.mediatypes OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ani_contacts; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_contacts (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    responsible_id integer,
    "position" character varying(128),
    company_id integer
);


ALTER TABLE public.ani_contacts OWNER TO anicrm;

--
-- Name: ani_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_contacts_id_seq OWNER TO anicrm;

--
-- Name: ani_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anicrm
--

ALTER SEQUENCE ani_contacts_id_seq OWNED BY ani_contacts.id;


--
-- Name: ani_emails_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_emails_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_emails_id_seq OWNER TO anicrm;

--
-- Name: ani_emails; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_emails (
    id integer DEFAULT nextval('ani_emails_id_seq'::regclass) NOT NULL,
    email character varying(128) NOT NULL,
    media_type_id integer NOT NULL,
    contact_id integer
);


ALTER TABLE public.ani_emails OWNER TO anicrm;

--
-- Name: ani_files; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_files (
    id integer NOT NULL,
    size integer NOT NULL,
    content_type character varying(255),
    subdir character varying(255),
    name character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    description character varying(512),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    contact_id integer
);


ALTER TABLE public.ani_files OWNER TO anicrm;

--
-- Name: ani_files_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_files_id_seq OWNER TO anicrm;

--
-- Name: ani_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anicrm
--

ALTER SEQUENCE ani_files_id_seq OWNED BY ani_files.id;


--
-- Name: ani_media_types_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_media_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_media_types_id_seq OWNER TO anicrm;

--
-- Name: ani_media_types; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_media_types (
    id integer DEFAULT nextval('ani_media_types_id_seq'::regclass) NOT NULL,
    name character varying(128) NOT NULL,
    type mediatypes NOT NULL
);


ALTER TABLE public.ani_media_types OWNER TO anicrm;

--
-- Name: ani_messengers_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_messengers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_messengers_id_seq OWNER TO anicrm;

--
-- Name: ani_messengers; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_messengers (
    id integer DEFAULT nextval('ani_messengers_id_seq'::regclass) NOT NULL,
    value character varying(128) NOT NULL,
    media_type_id integer NOT NULL,
    contact_id integer
);


ALTER TABLE public.ani_messengers OWNER TO anicrm;

--
-- Name: ani_migrations; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_migrations (
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.ani_migrations OWNER TO anicrm;

--
-- Name: ani_phones; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_phones (
    id integer DEFAULT nextval('ani_contacts_id_seq'::regclass) NOT NULL,
    phone character varying(64) NOT NULL,
    media_type_id integer NOT NULL,
    contact_id integer
);


ALTER TABLE public.ani_phones OWNER TO anicrm;

--
-- Name: ani_phones_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_phones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_phones_id_seq OWNER TO anicrm;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: anicrm
--

ALTER TABLE ONLY ani_contacts ALTER COLUMN id SET DEFAULT nextval('ani_contacts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: anicrm
--

ALTER TABLE ONLY ani_files ALTER COLUMN id SET DEFAULT nextval('ani_files_id_seq'::regclass);


--
-- Data for Name: ani_contacts; Type: TABLE DATA; Schema: public; Owner: anicrm
--

INSERT INTO ani_contacts VALUES (7482, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:07:26', '2015-01-22 16:07:26', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7485, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:08:18', '2015-01-22 16:08:18', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7487, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:08:48', '2015-01-22 16:08:48', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7489, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:09:18', '2015-01-22 16:09:18', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7491, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:10:04', '2015-01-22 16:10:04', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7493, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:11:18', '2015-01-22 16:11:18', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7495, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:47:55', '2015-01-22 16:47:55', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7497, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:50:22', '2015-01-22 16:50:22', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7499, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:51:25', '2015-01-22 16:51:25', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7500, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:51:40', '2015-01-22 16:51:40', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7502, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:51:59', '2015-01-22 16:51:59', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7503, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:52:20', '2015-01-22 16:52:20', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7504, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:52:54', '2015-01-22 16:52:54', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7505, NULL, 'Евгений Петрович', '2015-01-22 17:01:37', '2015-01-22 17:10:22', 1, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7523, NULL, 'Тест', '2015-01-22 18:54:39', '2015-01-22 18:54:39', 1, 'Тест', NULL);
INSERT INTO ani_contacts VALUES (7896, NULL, 'Петрушка', '2015-01-26 13:39:24', '2015-01-26 13:39:24', 2, 'Никто', NULL);
INSERT INTO ani_contacts VALUES (7536, NULL, 'Коломойский И.', '2015-01-23 13:45:20', '2015-01-23 17:11:18', 12, 'Олигарх', NULL);
INSERT INTO ani_contacts VALUES (7898, NULL, 'Петруха', '2015-01-26 13:40:37', '2015-01-26 13:40:37', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7900, NULL, 'Петруха', '2015-01-26 13:49:40', '2015-01-26 13:49:40', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7475, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 15:57:56', '2015-01-26 15:31:55', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7825, NULL, 'Дорофеев Андрей Николаевич', '2015-01-26 09:56:07', '2015-01-26 09:56:07', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7828, NULL, 'Дорофеев Андрей Николаевич', '2015-01-26 09:56:07', '2015-01-26 09:56:07', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7829, NULL, 'Дорофеев Андрей Николаевич', '2015-01-26 09:56:52', '2015-01-26 09:56:52', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7832, NULL, 'Дорофеев Андрей Николаевич', '2015-01-26 09:59:02', '2015-01-26 09:59:02', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7835, NULL, 'Дорофеев Андрей Николаевич', '2015-01-26 10:00:13', '2015-01-26 10:00:13', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7838, NULL, 'Дорофеев Андрей Николаевич', '2015-01-26 10:00:57', '2015-01-26 10:00:57', NULL, 'Программис', NULL);
INSERT INTO ani_contacts VALUES (7840, NULL, 'Дорофеев Андрей Николаевич', '2015-01-26 10:01:24', '2015-01-26 10:01:24', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7755, NULL, 'Дорофеев Андрей Николаевич', '2015-01-23 18:27:12', '2015-01-26 10:02:09', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7484, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:07:35', '2015-01-26 10:49:01', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7472, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 15:49:29', '2015-01-26 10:49:31', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7951, NULL, 'Дороф', '2015-01-26 16:17:17', '2015-01-26 16:17:17', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7438, NULL, 'Andrew', '2014-10-27 18:06:09', '2015-01-26 16:19:40', NULL, 'agent', NULL);
INSERT INTO ani_contacts VALUES (7473, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 15:51:01', '2015-01-26 11:39:14', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (8139, NULL, 'Тест', '2015-01-27 18:30:19', '2015-01-27 18:30:19', NULL, 'Машинист', NULL);
INSERT INTO ani_contacts VALUES (8143, NULL, 'Новый контакт', '2015-01-28 19:22:36', '2015-01-28 19:22:36', NULL, 'Механие', NULL);
INSERT INTO ani_contacts VALUES (7953, NULL, 'Андрей', '2015-01-26 16:20:04', '2015-01-26 16:31:15', NULL, 'Ктототам', NULL);
INSERT INTO ani_contacts VALUES (7477, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:03:36', '2015-01-26 16:40:20', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7967, NULL, 'Паша', '2015-01-26 16:44:36', '2015-01-26 16:44:36', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7968, NULL, 'Афанасий', '2015-01-26 16:46:35', '2015-01-26 16:46:35', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7969, NULL, 'Афанасий', '2015-01-26 16:49:10', '2015-01-26 16:49:10', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7970, NULL, 'Афанасий', '2015-01-26 16:49:26', '2015-01-26 16:49:26', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7971, NULL, 'Валентин Игнатьевич', '2015-01-26 16:58:27', '2015-01-26 16:58:27', NULL, 'Менеджер', NULL);
INSERT INTO ani_contacts VALUES (7479, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:06:06', '2015-01-26 16:59:17', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (7974, NULL, 'Тест', '2015-01-26 17:05:06', '2015-01-26 17:05:06', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7976, NULL, 'фывфывфывыв', '2015-01-26 17:08:52', '2015-01-26 17:08:52', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (7977, NULL, 'Петрович', '2015-01-26 17:31:15', '2015-01-26 17:31:15', NULL, 'Сантехник', NULL);
INSERT INTO ani_contacts VALUES (7480, NULL, 'Дорофеев Андрей Николаевич', '2015-01-22 16:07:15', '2015-01-27 08:52:32', NULL, 'Программист', NULL);
INSERT INTO ani_contacts VALUES (8036, NULL, 'Буранов Олег', '2015-01-27 08:54:16', '2015-01-27 08:54:16', NULL, 'Тестировщик', NULL);
INSERT INTO ani_contacts VALUES (8053, NULL, '13123123', '2015-01-27 08:59:11', '2015-01-27 08:59:11', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (8054, NULL, '113', '2015-01-27 09:06:26', '2015-01-27 09:06:26', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (8055, NULL, '113123131', '2015-01-27 09:14:04', '2015-01-27 09:16:21', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (8096, NULL, 'asdasda', '2015-01-27 11:00:19', '2015-01-27 11:00:19', NULL, 'adasd', NULL);
INSERT INTO ani_contacts VALUES (8106, NULL, 'adada', '2015-01-27 11:01:30', '2015-01-27 11:20:43', NULL, 'asdaa', NULL);
INSERT INTO ani_contacts VALUES (8116, NULL, 'Дюжев Дмитрий', '2015-01-27 11:21:33', '2015-01-27 11:21:33', NULL, 'Актер', NULL);
INSERT INTO ani_contacts VALUES (8121, NULL, 'Александр Артемов', '2015-01-27 14:52:39', '2015-01-27 14:52:39', NULL, 'директор', NULL);
INSERT INTO ani_contacts VALUES (8124, NULL, 'asdasds', '2015-01-27 15:07:10', '2015-01-27 15:07:10', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (8126, NULL, 'Арутюнян Артем', '2015-01-27 15:20:57', '2015-01-27 15:20:57', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (8177, NULL, 'asdasda', '2015-02-02 15:17:22', '2015-02-02 15:18:05', 2, '', NULL);
INSERT INTO ani_contacts VALUES (8147, NULL, 'Миша1', '2015-01-29 10:43:53', '2015-02-02 15:18:21', NULL, '', NULL);
INSERT INTO ani_contacts VALUES (8180, NULL, '12312', '2015-02-15 21:33:10', '2015-02-15 21:33:10', NULL, '', NULL);


--
-- Name: ani_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_contacts_id_seq', 8180, true);


--
-- Data for Name: ani_emails; Type: TABLE DATA; Schema: public; Owner: anicrm
--

INSERT INTO ani_emails VALUES (1, 'andrew.dorofeev@aniart.com.ua', 25, 7465);
INSERT INTO ani_emails VALUES (2, 'damianwnet@gmail.com', 8, 7465);
INSERT INTO ani_emails VALUES (3, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (4, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (5, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (6, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (7, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (8, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (9, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (10, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (11, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (12, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (13, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (14, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (15, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (16, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (17, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (18, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (19, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (20, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (21, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (22, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (23, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (24, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (25, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (26, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (27, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (28, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (29, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (30, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (31, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (32, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (33, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (34, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (35, 'damianwnet@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (36, 'andrew.dorofeev@gmail.com', 8, 7505);
INSERT INTO ani_emails VALUES (37, 'damianwnet@gmail.com', 8, 7523);
INSERT INTO ani_emails VALUES (38, 'damianwnet@gmail.com', 8, 7523);
INSERT INTO ani_emails VALUES (39, 'damianwnet@gmail.com', 8, 7523);
INSERT INTO ani_emails VALUES (40, 'damianwnet@gmail.com', 8, 7523);
INSERT INTO ani_emails VALUES (41, 'damianwnet@gmail.com', 8, 7523);
INSERT INTO ani_emails VALUES (42, 'damianwnet@gmail.com', 8, 7523);
INSERT INTO ani_emails VALUES (256, 'test@test.ua', 25, 8143);
INSERT INTO ani_emails VALUES (107, 'damiwnet@gmail.com', 8, 7825);
INSERT INTO ani_emails VALUES (108, 'damiwnet@gmail.com', 8, 7829);
INSERT INTO ani_emails VALUES (109, 'damiwnet@gmail.com', 8, 7832);
INSERT INTO ani_emails VALUES (110, 'andrew.dorofeev@gmail.com', 8, 7832);
INSERT INTO ani_emails VALUES (111, 'damiwnet@gmail.com', 8, 7835);
INSERT INTO ani_emails VALUES (112, 'damiwnet@gmail.com', 8, 7838);
INSERT INTO ani_emails VALUES (113, 'damiwnet@gmail.com', 8, 7840);
INSERT INTO ani_emails VALUES (58, 'damianwnet@gmail.com', 8, 7536);
INSERT INTO ani_emails VALUES (266, 'test@test.tes', 8, 7482);
INSERT INTO ani_emails VALUES (200, 'test@test.ua', 8, 7977);
INSERT INTO ani_emails VALUES (201, 'aaa@aa.ua', 8, 7977);
INSERT INTO ani_emails VALUES (137, 'damianwnet@gmail.com', 8, 7473);
INSERT INTO ani_emails VALUES (138, 'test@test.test', 8, 7896);
INSERT INTO ani_emails VALUES (216, 'test@test.test', 8, 8036);
INSERT INTO ani_emails VALUES (217, 'test@test1.test', 8, 8036);
INSERT INTO ani_emails VALUES (156, 'damianwnet@gmail.com', 8, 7900);
INSERT INTO ani_emails VALUES (157, 'a@test.ua', 8, 7971);
INSERT INTO ani_emails VALUES (226, 'asdasd@adasd.test', 8, 8055);
INSERT INTO ani_emails VALUES (230, 'aaa@aa.ua', 8, 8096);
INSERT INTO ani_emails VALUES (234, 'damianwnet@gmail.com', 8, 8106);
INSERT INTO ani_emails VALUES (235, 'test@test.ua', 8, 8106);
INSERT INTO ani_emails VALUES (239, 'aaa@aa.aa', 8, 8116);
INSERT INTO ani_emails VALUES (240, 'avdov@narod.ru', 8, 8121);
INSERT INTO ani_emails VALUES (241, 'managers@aniart.com.ua', 8, 8126);
INSERT INTO ani_emails VALUES (250, 'damiwnet@gmail.com', 8, 7755);
INSERT INTO ani_emails VALUES (251, 'andrew.dorofeev@gmail.com', 8, 7755);
INSERT INTO ani_emails VALUES (254, 'ea@aa.aa', 8, 8139);


--
-- Name: ani_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_emails_id_seq', 266, true);


--
-- Data for Name: ani_files; Type: TABLE DATA; Schema: public; Owner: anicrm
--

INSERT INTO ani_files VALUES (1, 38081, 'application/xml', 'a76', '319de9e4218c6ea5946d59e3ceafe7b9.xls', 'a76beca8788fcdc7a81627b6458c1e1f.xls', NULL, '2015-01-19 17:36:17', '2015-01-19 17:36:17', NULL);
INSERT INTO ani_files VALUES (2, 38081, 'application/xml', '135', 'a44ce52e7ddc28e61481ce6286cc3d56.xls', '135fd655a79f2f802afe7e5f4517adad.xls', NULL, '2015-01-19 18:08:18', '2015-01-19 18:08:18', NULL);
INSERT INTO ani_files VALUES (3, 3208, 'image/gif', '5a6', '5a6aaa2196fe721deb77b3d1bb4b3583.gif', 'ajax-loader.gif', NULL, '2015-01-19 18:22:08', '2015-01-19 18:22:08', NULL);
INSERT INTO ani_files VALUES (4, 1039, 'text/plain', 'b31', 'b31081592542b85086224abed0e36c0c.csv', 'example_contacts_ru.csv', NULL, '2015-01-19 18:23:17', '2015-01-19 18:23:17', NULL);
INSERT INTO ani_files VALUES (5, 38081, 'application/xml', '67e', '67e36f74015ced04710e5229be9fd24c.xls', 'advertisement.xls', NULL, '2015-01-19 18:37:41', '2015-01-19 18:37:41', NULL);
INSERT INTO ani_files VALUES (6, 38081, 'application/xml', '803', '803128f9d01353b111b764b2af4141c6.xls', 'advertisement.xls', NULL, '2015-01-19 18:44:51', '2015-01-19 18:44:51', NULL);
INSERT INTO ani_files VALUES (7, 38081, 'application/xml', 'c09', 'c09e0d597713d185a7a1693254456f5d.xls', 'advertisement.xls', NULL, '2015-01-20 06:56:58', '2015-01-20 06:56:58', NULL);
INSERT INTO ani_files VALUES (8, 1163, 'image/png', 'da5', 'da59d1bae58dfbcfb6d08a4bef940252.png', '7.png', NULL, '2015-01-26 07:47:14', '2015-01-26 07:47:14', NULL);
INSERT INTO ani_files VALUES (9, 395750, 'image/png', '551', '551119fcdd4355907aa4cb2d24c885be.png', '75553206.png', NULL, '2015-01-26 07:47:14', '2015-01-26 07:47:14', NULL);
INSERT INTO ani_files VALUES (10, 1163, 'image/png', '164', '164b0711670cc2bd3c248497f60a9d07.png', '7.png', NULL, '2015-01-26 08:11:50', '2015-01-26 08:11:50', NULL);
INSERT INTO ani_files VALUES (11, 395750, 'image/png', 'cda', 'cdaba1355d2cd85549a0f20192321f0c.png', '75553206.png', NULL, '2015-01-26 08:11:50', '2015-01-26 08:11:50', NULL);
INSERT INTO ani_files VALUES (12, 1163, 'image/png', 'e14', 'e14bc4761ca66a10bd5516f420f420bb.png', '7.png', NULL, '2015-01-26 08:12:07', '2015-01-26 08:12:07', NULL);
INSERT INTO ani_files VALUES (13, 395750, 'image/png', '504', '504144a23dd8755c6c9e712f5ba2b80a.png', '75553206.png', NULL, '2015-01-26 08:12:07', '2015-01-26 08:12:07', NULL);
INSERT INTO ani_files VALUES (14, 1163, 'image/png', 'e75', 'e758f7888507f09c99549ba1a7fc4942.png', '7.png', NULL, '2015-01-26 08:14:43', '2015-01-26 08:14:43', NULL);
INSERT INTO ani_files VALUES (15, 395750, 'image/png', '448', '448994aecd787f8553320efa8e9918a7.png', '75553206.png', NULL, '2015-01-26 08:14:43', '2015-01-26 08:14:43', NULL);
INSERT INTO ani_files VALUES (16, 1163, 'image/png', '22e', '22e04a05ad893aaf808c40cda75b700c.png', '7.png', NULL, '2015-01-26 08:25:40', '2015-01-26 08:25:40', NULL);
INSERT INTO ani_files VALUES (17, 395750, 'image/png', '696', '6960edc31a3298b61dcdd3393fa38c75.png', '75553206.png', NULL, '2015-01-26 08:25:40', '2015-01-26 08:25:40', NULL);
INSERT INTO ani_files VALUES (18, 1163, 'image/png', '3ca', '3ca9ffd051cbe145af000b5c99af8923.png', '7.png', NULL, '2015-01-26 08:26:20', '2015-01-26 08:26:20', NULL);
INSERT INTO ani_files VALUES (19, 395750, 'image/png', 'abb', 'abbc0f4af51c1881c3c51efefd79be19.png', '75553206.png', NULL, '2015-01-26 08:26:21', '2015-01-26 08:26:21', NULL);
INSERT INTO ani_files VALUES (44, 22370, 'text/plain', '3c7', '3c7a935b88319d9b54dcd9c92fae1647.csv', 'contacts.csv', NULL, '2015-01-26 11:33:03', '2015-01-26 11:33:04', 7473);
INSERT INTO ani_files VALUES (22, 3208, 'image/gif', '979', '9792bfa0ff8958fca3a086f996a49a88.gif', 'ajax-loader.gif', NULL, '2015-01-26 08:42:07', '2015-01-26 08:42:07', NULL);
INSERT INTO ani_files VALUES (23, 1163, 'image/png', 'b3f', 'b3fcfd07fe564389f0980930f8059aad.png', '7.png', NULL, '2015-01-26 08:46:36', '2015-01-26 08:46:36', NULL);
INSERT INTO ani_files VALUES (24, 3208, 'image/gif', '8de', '8de899d7e07079a869bdc97de6089616.gif', 'ajax-loader.gif', NULL, '2015-01-26 08:54:26', '2015-01-26 08:54:26', NULL);
INSERT INTO ani_files VALUES (25, 3208, 'image/gif', 'f69', 'f6970f511f8415f062daaf7475617590.gif', 'ajax-loader.gif', NULL, '2015-01-26 09:21:19', '2015-01-26 09:21:19', NULL);
INSERT INTO ani_files VALUES (26, 3208, 'image/gif', '399', '399783d88f5fabcc45b25978cb40436d.gif', 'ajax-loader.gif', NULL, '2015-01-26 09:22:53', '2015-01-26 09:22:53', NULL);
INSERT INTO ani_files VALUES (27, 3208, 'image/gif', 'ba7', 'ba71207f0ef61a4734d14b392a23926e.gif', 'ajax-loader.gif', NULL, '2015-01-26 09:30:53', '2015-01-26 09:30:53', NULL);
INSERT INTO ani_files VALUES (28, 3208, 'image/gif', '494', '494620f8374fc20b84955a27cce1fa3d.gif', 'ajax-loader.gif', NULL, '2015-01-26 09:31:57', '2015-01-26 09:31:57', NULL);
INSERT INTO ani_files VALUES (29, 3208, 'image/gif', '536', '536533d5790bc10e0a0e112c6a1c4ad8.gif', 'ajax-loader.gif', NULL, '2015-01-26 09:45:28', '2015-01-26 09:45:28', NULL);
INSERT INTO ani_files VALUES (20, 1163, 'image/png', 'b62', 'b620588c8517561848ede78fa99258ce.png', '7.png', NULL, '2015-01-26 08:28:24', '2015-01-26 09:56:07', 7825);
INSERT INTO ani_files VALUES (21, 395750, 'image/png', 'f97', 'f97fa653d0c428a74871d3d9e682dd0d.png', '75553206.png', NULL, '2015-01-26 08:28:25', '2015-01-26 09:56:07', 7825);
INSERT INTO ani_files VALUES (30, 3208, 'image/gif', 'f33', 'f33b54964f89c98868b652a798d86aa6.gif', 'ajax-loader.gif', NULL, '2015-01-26 09:56:07', '2015-01-26 09:56:07', 7828);
INSERT INTO ani_files VALUES (31, 1163, 'image/png', '02a', '02a83ab07558109239a4464829e80508.png', '7.png', NULL, '2015-01-26 10:03:23', '2015-01-26 10:03:23', NULL);
INSERT INTO ani_files VALUES (32, 395750, 'image/png', '55f', '55f379549d4c491b48a4ac6da43cd7f0.png', '75553206.png', NULL, '2015-01-26 10:03:24', '2015-01-26 10:03:24', NULL);
INSERT INTO ani_files VALUES (33, 1163, 'image/png', '404', '40404c09e8f6c08398ba66b0a4fdbbef.png', '7.png', NULL, '2015-01-26 10:15:41', '2015-01-26 10:15:41', NULL);
INSERT INTO ani_files VALUES (34, 395750, 'image/png', 'c0c', 'c0cf97604d4e1db2966e1df8d3ae97a0.png', '75553206.png', NULL, '2015-01-26 10:15:42', '2015-01-26 10:15:42', NULL);
INSERT INTO ani_files VALUES (39, 1163, 'image/png', '705', '7051d7c9c2ab5ac38af38b67432f7c42.png', '7.png', NULL, '2015-01-26 10:53:59', '2015-01-26 10:53:59', 7473);
INSERT INTO ani_files VALUES (40, 395750, 'image/png', '676', '676e0c21e07bc286fa882d1ef5eeef54.png', '75553206.png', NULL, '2015-01-26 10:54:40', '2015-01-26 10:54:40', 7473);
INSERT INTO ani_files VALUES (41, 395750, 'image/png', 'b6a', 'b6abe9a85f1d38da395096dbc31ac015.png', '75553206.png', NULL, '2015-01-26 10:54:50', '2015-01-26 10:54:50', 7473);
INSERT INTO ani_files VALUES (42, 1163, 'image/png', '334', '334248f2ad12f6e8adf72d3404fbfcfb.png', '7.png', NULL, '2015-01-26 10:57:11', '2015-01-26 10:57:12', 7473);
INSERT INTO ani_files VALUES (43, 127294, 'text/x-c++', '987', '9876b35a3900f3a84519727195401a48.php', 'bx_1c_import.php', NULL, '2015-01-26 11:22:11', '2015-01-26 11:22:11', 7473);
INSERT INTO ani_files VALUES (45, 1163, 'image/png', '13c', '13c889b344dd9ec2a518ab661983c558.png', '7.png', NULL, '2015-01-26 13:54:04', '2015-01-26 13:54:04', NULL);
INSERT INTO ani_files VALUES (46, 1163, 'image/png', '23e', '23e3e6208e0eb9c4f18053a686605a28.png', '7.png', NULL, '2015-01-26 13:55:15', '2015-01-26 13:55:15', NULL);
INSERT INTO ani_files VALUES (47, 1163, 'image/png', 'b0f', 'b0ffdaaea730a0753fc97292edca82f6.png', '7.png', NULL, '2015-01-26 13:56:53', '2015-01-26 13:56:53', NULL);
INSERT INTO ani_files VALUES (48, 1163, 'image/png', 'b17', 'b170b2ee3b83a400290c13278e1202dd.png', '7.png', NULL, '2015-01-26 13:58:59', '2015-01-26 13:58:59', NULL);
INSERT INTO ani_files VALUES (49, 1163, 'image/png', 'd76', 'd768a916deb034eb8da68fc49f1c56e4.png', '7.png', NULL, '2015-01-26 14:16:24', '2015-01-26 14:16:24', NULL);
INSERT INTO ani_files VALUES (50, 1163, 'image/png', '433', '4339088f2f96a2c3718fa88fa9bb5745.png', '7.png', NULL, '2015-01-26 14:51:44', '2015-01-26 14:51:44', NULL);
INSERT INTO ani_files VALUES (51, 395750, 'image/png', 'a19', 'a194dc3faca07c3eda85aca4cde9056d.png', '75553206.png', NULL, '2015-01-26 14:51:45', '2015-01-26 14:51:45', NULL);
INSERT INTO ani_files VALUES (52, 1163, 'image/png', 'c07', 'c0701249f33e013c5c8e5f3cd85aa59e.png', '7.png', NULL, '2015-01-26 14:54:58', '2015-01-26 14:54:58', NULL);
INSERT INTO ani_files VALUES (53, 1163, 'image/png', 'd49', 'd49dbad135c10b71d90d886db858df5f.png', '7.png', NULL, '2015-01-26 15:11:04', '2015-01-26 15:11:04', NULL);
INSERT INTO ani_files VALUES (54, 395750, 'image/png', 'ad5', 'ad5390bf0df290cfecf49e053382c9a3.png', '75553206.png', NULL, '2015-01-26 15:16:05', '2015-01-26 15:16:05', NULL);
INSERT INTO ani_files VALUES (55, 1163, 'image/png', 'ac7', 'ac7e237414806747dcf9df68a18458dd.png', '7.png', NULL, '2015-01-26 15:16:46', '2015-01-26 15:16:46', NULL);
INSERT INTO ani_files VALUES (56, 1163, 'image/png', 'fea', 'fea8f2f4136ec5a6d4ceafacbf96f0d2.png', '7.png', NULL, '2015-01-26 15:17:13', '2015-01-26 15:17:14', 7900);
INSERT INTO ani_files VALUES (57, 3208, 'image/gif', 'c5b', 'c5bf9031439fa25d62730935b324a158.gif', 'ajax-loader.gif', NULL, '2015-01-26 15:17:13', '2015-01-26 15:17:14', 7900);
INSERT INTO ani_files VALUES (58, 395750, 'image/png', 'e96', 'e9647bf07aae7b7d66fc3e5dedcbf120.png', '75553206.png', NULL, '2015-01-26 15:17:13', '2015-01-26 15:17:14', 7900);
INSERT INTO ani_files VALUES (59, 38081, 'application/xml', 'ddc', 'ddcb7929bd4ed5048998c4b6dc4a8aec.xls', 'advertisement.xls', NULL, '2015-01-26 15:17:14', '2015-01-26 15:17:14', 7900);
INSERT INTO ani_files VALUES (60, 1163, 'image/png', 'b8d', 'b8dabad577e7cd712030fb9d7ab53143.png', '7.png', NULL, '2015-01-26 15:17:43', '2015-01-26 15:17:43', 7900);
INSERT INTO ani_files VALUES (61, 395750, 'image/png', '18f', '18fc2737921357a504ff49df79af7018.png', '75553206.png', NULL, '2015-01-26 15:18:15', '2015-01-26 15:18:15', 7900);
INSERT INTO ani_files VALUES (62, 38081, 'application/xml', '7b6', '7b68e048fcb79cd0da9e608445b3077d.xls', 'advertisement.xls', NULL, '2015-01-26 15:18:28', '2015-01-26 15:18:28', 7900);
INSERT INTO ani_files VALUES (63, 1163, 'image/png', 'f41', 'f41d5102bcc45e636422c2b9a36dc18d.png', '7.png', NULL, '2015-01-26 15:20:22', '2015-01-26 15:20:22', 7900);
INSERT INTO ani_files VALUES (64, 1163, 'image/png', 'e4b', 'e4bfa425edb87b7437a769d03020e8a2.png', '7.png', NULL, '2015-01-26 15:21:37', '2015-01-26 15:21:37', 7900);
INSERT INTO ani_files VALUES (65, 127294, 'text/x-c++', '4e8', '4e88489ec75137fc705ddab71b381f7f.php', 'bx_1c_import.php', NULL, '2015-01-26 15:22:55', '2015-01-26 15:22:55', 7900);
INSERT INTO ani_files VALUES (66, 1163, 'image/png', '7c6', '7c6ea61531d15f6358511b20b9456739.png', '7.png', NULL, '2015-01-26 15:24:03', '2015-01-26 15:24:03', 7900);
INSERT INTO ani_files VALUES (67, 1163, 'image/png', '84a', '84a1d86e53892370db413ef4211b2d43.png', '7.png', NULL, '2015-01-26 15:26:34', '2015-01-26 15:26:34', NULL);
INSERT INTO ani_files VALUES (68, 1163, 'image/png', '69a', '69ac85b55ad944528621c7a3762158f9.png', '7.png', NULL, '2015-01-26 15:27:09', '2015-01-26 15:27:09', NULL);
INSERT INTO ani_files VALUES (69, 1163, 'image/png', '369', '369056fd9714d9b5bf2e2e03cee24dd5.png', '7.png', NULL, '2015-01-26 15:30:33', '2015-01-26 15:30:33', NULL);
INSERT INTO ani_files VALUES (70, 3208, 'image/gif', 'cbc', 'cbc77c932f293baf743d4498fcfc701e.gif', 'ajax-loader.gif', NULL, '2015-01-26 15:31:01', '2015-01-26 15:31:01', NULL);
INSERT INTO ani_files VALUES (71, 1163, 'image/png', 'acc', 'acca427e932c2604e7f306eda07065fb.png', '7.png', NULL, '2015-01-26 15:32:27', '2015-01-26 15:32:27', NULL);
INSERT INTO ani_files VALUES (72, 1163, 'image/png', '70f', '70fa8466d15b7f43e97416d62a9f010e.png', '7.png', NULL, '2015-01-26 15:33:57', '2015-01-26 15:33:57', NULL);
INSERT INTO ani_files VALUES (73, 1163, 'image/png', '006', '0062f85c7d62816d3f05560118044e5a.png', '7.png', NULL, '2015-01-26 15:36:06', '2015-01-26 15:36:06', 7475);
INSERT INTO ani_files VALUES (74, 395750, 'image/png', '951', '95186193031275b7bd5c0e8600664c76.png', '75553206.png', NULL, '2015-01-26 15:37:22', '2015-01-26 15:37:22', 7475);
INSERT INTO ani_files VALUES (75, 38081, 'application/xml', '77a', '77ae018b5a12f6c4edd9656a2e13176d.xls', 'advertisement.xls', NULL, '2015-01-26 15:39:02', '2015-01-26 15:39:02', 7475);
INSERT INTO ani_files VALUES (76, 1163, 'image/png', 'f1b', 'f1bb97c5b5e1e3ff5522d4f86e908188.png', '7.png', NULL, '2015-01-26 15:43:03', '2015-01-26 15:43:03', 7475);
INSERT INTO ani_files VALUES (77, 1163, 'image/png', '7b2', '7b274d5a6f03ba1eb9f32388c26e9340.png', '7.png', NULL, '2015-01-26 15:47:48', '2015-01-26 15:47:48', 7475);
INSERT INTO ani_files VALUES (78, 3208, 'image/gif', 'fed', 'fed4b2a22b7e8abef9c7897fe6f1b154.gif', 'ajax-loader.gif', NULL, '2015-01-26 15:49:36', '2015-01-26 15:49:37', 7475);
INSERT INTO ani_files VALUES (79, 1163, 'image/png', '68e', '68e691cafe95647718433407e9fa05a2.png', '7.png', NULL, '2015-01-26 16:20:18', '2015-01-26 16:20:19', 7953);
INSERT INTO ani_files VALUES (80, 395750, 'image/png', '84f', '84f26b17844de4773fe32501cc5da68f.png', '75553206.png', NULL, '2015-01-26 16:20:19', '2015-01-26 16:20:19', 7953);
INSERT INTO ani_files VALUES (81, 1163, 'image/png', '885', '885e2793f19c4815cea6f76f8fe08977.png', '7.png', NULL, '2015-01-26 16:31:15', '2015-01-26 16:31:15', 7953);
INSERT INTO ani_files VALUES (82, 395750, 'image/png', 'a9f', 'a9fe36055c900e6d2c1c929a64294379.png', '75553206.png', NULL, '2015-01-26 16:31:15', '2015-01-26 16:31:15', 7953);
INSERT INTO ani_files VALUES (83, 1163, 'image/png', '9fc', '9fc49620ebb41d39354a95fb6146c07a.png', '7.png', NULL, '2015-01-26 16:40:30', '2015-01-26 16:40:31', 7477);
INSERT INTO ani_files VALUES (84, 395750, 'image/png', '0c6', '0c6070361a78d70588fff8248701c26b.png', '75553206.png', NULL, '2015-01-26 16:40:31', '2015-01-26 16:40:31', 7477);
INSERT INTO ani_files VALUES (85, 1163, 'image/png', '7f2', '7f2c2513c28a85f4600ccc159d6d1883.png', '7.png', NULL, '2015-01-26 16:41:27', '2015-01-26 16:41:27', 7477);
INSERT INTO ani_files VALUES (86, 1163, 'image/png', 'e61', 'e6167675eb9fb739b2b5fd5728a62d23.png', '7.png', NULL, '2015-01-26 16:44:36', '2015-01-26 16:44:36', NULL);
INSERT INTO ani_files VALUES (87, 395750, 'image/png', '950', '9509b216341dc1d74757bfd3136ddc20.png', '75553206.png', NULL, '2015-01-26 16:44:36', '2015-01-26 16:44:36', NULL);
INSERT INTO ani_files VALUES (88, 1163, 'image/png', 'c99', 'c9915c90b88ed7331bc564e0a41baae5.png', '7.png', NULL, '2015-01-26 16:58:27', '2015-01-26 16:58:27', NULL);
INSERT INTO ani_files VALUES (89, 395750, 'image/png', '81a', '81a1ec1da432dffe200738449879150c.png', '75553206.png', NULL, '2015-01-26 16:58:28', '2015-01-26 16:58:28', NULL);
INSERT INTO ani_files VALUES (90, 1163, 'image/png', '595', '5951c88522100fa9e86a105bfbe2a8e6.png', '7.png', NULL, '2015-01-26 16:59:17', '2015-01-26 16:59:17', NULL);
INSERT INTO ani_files VALUES (91, 395750, 'image/png', '2fd', '2fd087603593cd685e632897f799a401.png', '75553206.png', NULL, '2015-01-26 16:59:18', '2015-01-26 16:59:18', NULL);
INSERT INTO ani_files VALUES (92, 1163, 'image/png', '4a9', '4a9de2713f2413ecd1346e9ec62c787c.png', '7.png', NULL, '2015-01-26 17:05:06', '2015-01-26 17:05:06', NULL);
INSERT INTO ani_files VALUES (93, 395750, 'image/png', 'da3', 'da3f5691269a1eefa7aaf1f6951c4480.png', '75553206.png', NULL, '2015-01-26 17:05:06', '2015-01-26 17:05:06', NULL);
INSERT INTO ani_files VALUES (94, 1163, 'image/png', 'b78', 'b78c083b1e8a3c98545d31022d4eec91.png', '7.png', NULL, '2015-01-26 17:08:52', '2015-01-26 17:08:52', NULL);
INSERT INTO ani_files VALUES (95, 1163, 'image/png', 'c31', 'c31124d7dab228579b66473d2d7f070b.png', '7.png', NULL, '2015-01-26 17:37:04', '2015-01-26 17:37:05', 7977);
INSERT INTO ani_files VALUES (96, 395750, 'image/png', 'c6b', 'c6ba6b2566db65524f1b1e45dd9854ed.png', '75553206.png', NULL, '2015-01-26 17:37:04', '2015-01-26 17:37:05', 7977);
INSERT INTO ani_files VALUES (97, 3208, 'image/gif', '1ce', '1ce85a6d4e5b19b9b8ccd925e6d767f1.gif', 'ajax-loader.gif', NULL, '2015-01-26 17:51:49', '2015-01-26 17:51:49', 7977);
INSERT INTO ani_files VALUES (98, 3208, 'image/gif', 'bc9', 'bc91ceb709b9c0ced4d16f5150c2482e.gif', 'ajax-loader.gif', NULL, '2015-01-26 17:54:00', '2015-01-26 17:54:00', 7977);
INSERT INTO ani_files VALUES (99, 27890, 'application/pdf', 'a6e', 'a6ed52038322133bbe39eeababa0eb50.pdf', 'КБ46від24.07.2014_1_ід_35131.pdf', NULL, '2015-01-27 08:19:52', '2015-01-27 08:19:52', 7977);
INSERT INTO ani_files VALUES (100, 27890, 'application/pdf', '415', '415369dbc49537cba0b7f6ea062c2e89.pdf', 'КБ46від24.07.2014_1_ід_35131 (1).pdf', NULL, '2015-01-27 08:19:52', '2015-01-27 08:19:52', 7977);
INSERT INTO ani_files VALUES (101, 1163, 'image/png', '32c', '32ceec8b9842834f18be262f686ceff7.png', '7.png', NULL, '2015-01-27 08:22:00', '2015-01-27 08:22:16', 7977);
INSERT INTO ani_files VALUES (102, 395750, 'image/png', '67f', '67f29dc7c51a78ff5de0c83c5a86e5ab.png', '75553206.png', NULL, '2015-01-27 08:22:01', '2015-01-27 08:22:16', 7977);
INSERT INTO ani_files VALUES (103, 1163, 'image/png', 'd6d', 'd6d0138d2e0512758f1a4d0b9385a1ec.png', '7.png', NULL, '2015-01-27 08:26:52', '2015-01-27 08:26:52', NULL);
INSERT INTO ani_files VALUES (104, 395750, 'image/png', 'c5f', 'c5fa4cf74d914bdca0d6ba5b22ea4424.png', '75553206.png', NULL, '2015-01-27 08:26:52', '2015-01-27 08:26:52', NULL);
INSERT INTO ani_files VALUES (105, 1163, 'image/png', '226', '22635d95a63a2f48572b16a73245808c.png', '7.png', NULL, '2015-01-27 08:32:27', '2015-01-27 08:32:29', 7977);
INSERT INTO ani_files VALUES (106, 1163, 'image/png', '762', '762cc4a8e54b9d14322fa6a24f288caa.png', '7.png', NULL, '2015-01-27 08:44:08', '2015-01-27 08:44:08', 7977);
INSERT INTO ani_files VALUES (107, 66163, 'application/xml', 'f2e', 'f2e4b1ada2d2d7e8b77bd91c737d5ac0.xml', 'orders1251.xml', NULL, '2015-01-27 08:47:56', '2015-01-27 08:47:56', NULL);
INSERT INTO ani_files VALUES (108, 199378, 'image/jpeg', '249', '249312d3250b234d0e9fb585803bec42.jpg', 'orders1251.jpg', NULL, '2015-01-27 08:47:56', '2015-01-27 08:47:56', NULL);
INSERT INTO ani_files VALUES (109, 1163, 'image/png', '6ab', '6ab7350cd6e2426b4bd565f97bc078ec.png', '7.png', NULL, '2015-01-27 08:52:32', '2015-01-27 08:52:32', NULL);
INSERT INTO ani_files VALUES (110, 1163, 'image/png', 'c46', 'c46f4dcddf88f310773cebd8eb068d68.png', '7.png', NULL, '2015-01-27 08:54:16', '2015-01-27 08:54:16', NULL);
INSERT INTO ani_files VALUES (111, 38081, 'application/xml', '6d0', '6d0066f094fb634a0bccafd5806f75b0.xls', 'advertisement.xls', NULL, '2015-01-27 08:54:16', '2015-01-27 08:54:16', NULL);
INSERT INTO ani_files VALUES (112, 395750, 'image/png', '4e1', '4e1e402318d4c9842a0647f31b2d5424.png', '75553206.png', NULL, '2015-01-27 08:54:17', '2015-01-27 08:54:17', NULL);
INSERT INTO ani_files VALUES (113, 1163, 'image/png', '2e2', '2e233b32af12bf97c606c53463fe00a6.png', '7.png', NULL, '2015-01-27 08:56:56', '2015-01-27 08:56:57', 8036);
INSERT INTO ani_files VALUES (114, 395750, 'image/png', 'b09', 'b0969d6ad4708c596e8f5ef2c441b921.png', '75553206.png', NULL, '2015-01-27 08:56:56', '2015-01-27 08:56:57', 8036);
INSERT INTO ani_files VALUES (115, 1163, 'image/png', 'd93', 'd932c37e0b981fd66ae884f2a5864406.png', '7.png', NULL, '2015-01-27 08:59:11', '2015-01-27 08:59:11', NULL);
INSERT INTO ani_files VALUES (116, 1163, 'image/png', '7f8', '7f838d1e54010d3771db65b799f7e49a.png', '7.png', NULL, '2015-01-27 09:06:55', '2015-01-27 09:06:55', NULL);
INSERT INTO ani_files VALUES (117, 1163, 'image/png', 'bdb', 'bdb719695265f57409652318a8393bc7.png', '7.png', NULL, '2015-01-27 09:14:04', '2015-01-27 09:14:05', 8055);
INSERT INTO ani_files VALUES (118, 395750, 'image/png', 'f30', 'f30ee42665385ee44c50a31bc24eedd7.png', '75553206.png', NULL, '2015-01-27 09:14:05', '2015-01-27 09:14:05', 8055);
INSERT INTO ani_files VALUES (119, 1163, 'image/png', 'fb3', 'fb3c2cd85aaa2f371eeb17e11ae54a9b.png', '7.png', NULL, '2015-01-27 09:53:37', '2015-01-27 09:53:38', 8055);
INSERT INTO ani_files VALUES (120, 1163, 'image/png', '33a', '33a88f836eceb64c84b224db843889fd.png', '7.png', NULL, '2015-01-27 11:00:19', '2015-01-27 11:00:20', 8096);
INSERT INTO ani_files VALUES (121, 395750, 'image/png', 'aef', 'aeff2580e8aa447095f4c89ba8c4a20f.png', '75553206.png', NULL, '2015-01-27 11:00:19', '2015-01-27 11:00:20', 8096);
INSERT INTO ani_files VALUES (122, 1163, 'image/png', '020', '0200754a28f2fb2344bbbf0776e1d3ce.png', '7.png', NULL, '2015-01-27 11:01:03', '2015-01-27 11:01:03', 8096);
INSERT INTO ani_files VALUES (123, 1163, 'image/png', '279', '2790c58bb7818481f26ac933e138a93b.png', '7.png', NULL, '2015-01-27 11:14:38', '2015-01-27 11:14:38', 8106);
INSERT INTO ani_files VALUES (124, 3208, 'image/gif', 'f73', 'f731d343272bb2191e72799bdbde6ce1.gif', 'ajax-loader.gif', NULL, '2015-01-27 11:14:38', '2015-01-27 11:14:38', 8106);
INSERT INTO ani_files VALUES (125, 38081, 'application/xml', '0f9', '0f9ba2438c866db390a3013c7dcd9351.xls', 'advertisement.xls', NULL, '2015-01-27 11:14:38', '2015-01-27 11:14:38', 8106);
INSERT INTO ani_files VALUES (126, 395750, 'image/png', '209', '2093c9994e3dde768e67b60ca16f378d.png', '75553206.png', NULL, '2015-01-27 11:14:38', '2015-01-27 11:14:38', 8106);
INSERT INTO ani_files VALUES (127, 64000, 'application/vnd.ms-excel', '6f1', '6f12a411ff50e5f7ce7084315e724be3.xls', '{F94DC5FD-DDF0-4111-BDBA-C76D38D421A7}RUKAVYCHKA 1504.xls', NULL, '2015-01-27 11:20:44', '2015-01-27 11:20:44', 8106);
INSERT INTO ani_files VALUES (150, 1163, 'image/png', 'e0b', 'e0ba924b0563b77309bf2a154fad33c0.png', '7.png', NULL, '2015-01-27 18:30:19', '2015-01-27 18:30:20', 8139);
INSERT INTO ani_files VALUES (151, 38081, 'application/xml', '42f', '42f6531fb27a97b8456a3e8ab54d3e6d.xls', 'advertisement.xls', NULL, '2015-01-27 18:30:19', '2015-01-27 18:30:20', 8139);
INSERT INTO ani_files VALUES (133, 38081, 'application/xml', '8ba', '8ba53405843fd1f5b272daf242da1f0d.xls', 'advertisement.xls', NULL, '2015-01-27 12:17:56', '2015-01-27 12:17:56', 8116);
INSERT INTO ani_files VALUES (134, 64698, 'image/jpeg', '629', '6294b4612f10036b4feb4245a9c510da.jpg', '1389218067_poker.jpg', NULL, '2015-01-27 15:07:11', '2015-01-27 15:07:11', 8124);
INSERT INTO ani_files VALUES (152, 395750, 'image/png', 'b54', 'b543c4e573ae312b49e7575d7788f925.png', '75553206.png', NULL, '2015-01-27 18:30:20', '2015-01-27 18:30:20', 8139);
INSERT INTO ani_files VALUES (153, 1163, 'image/png', '170', '170b9a6232b6d04481efa3201e78bdf1.png', '7.png', NULL, '2015-01-28 09:27:19', '2015-01-28 09:27:20', 8139);
INSERT INTO ani_files VALUES (154, 395750, 'image/png', '42f', '42fe884694e6606e270e3955d864c46c.png', '75553206.png', NULL, '2015-01-28 09:27:20', '2015-01-28 09:27:20', 8139);
INSERT INTO ani_files VALUES (155, 31664, 'image/jpeg', '465', '465b1db81ebe7a441419b2a14f693bc6.jpg', '1329898353_andrey-yarmolenko.jpg', NULL, '2015-01-28 19:22:36', '2015-01-28 19:22:38', 8143);
INSERT INTO ani_files VALUES (156, 40231, 'image/jpeg', '966', '966182d80550c21ca6fc12b7753c37bf.jpg', 'lyric_girl.jpg', NULL, '2015-01-28 19:22:37', '2015-01-28 19:22:38', 8143);
INSERT INTO ani_files VALUES (157, 1163, 'image/png', '3d8', '3d8b716c7f15a22d6e845db7c1a1fe6a.png', '7.png', NULL, '2015-01-29 10:43:53', '2015-01-29 10:43:55', 8147);
INSERT INTO ani_files VALUES (158, 38081, 'application/xml', '6a3', '6a36dd94bd54bcc4e4416a4aa45e70cb.xls', 'advertisement.xls', NULL, '2015-01-29 10:43:53', '2015-01-29 10:43:55', 8147);
INSERT INTO ani_files VALUES (161, 395750, 'image/png', 'fd8', 'fd823507b8ade34b92f93891fda6ca4c.png', '75553206.png', NULL, '2015-01-31 14:14:12', '2015-01-31 14:14:12', 7482);
INSERT INTO ani_files VALUES (162, 38081, 'application/xml', '1f0', '1f0468aa4085b0b8e4bf5ef60b2f1647.xls', 'advertisement.xls', NULL, '2015-02-02 13:59:05', '2015-02-02 13:59:05', NULL);
INSERT INTO ani_files VALUES (163, 395750, 'image/png', 'f34', 'f342ac994bd9354445d2d8db84e51cc6.png', '75553206.png', NULL, '2015-02-02 13:59:05', '2015-02-02 13:59:05', NULL);
INSERT INTO ani_files VALUES (166, 369028, 'image/jpeg', '557', '5577425cca4423ac060a4e9f9c6d0555.jpg', 'skopa2.jpg', NULL, '2015-02-15 21:33:11', '2015-02-15 21:33:12', 8180);
INSERT INTO ani_files VALUES (167, 352691, 'image/jpeg', 'f2b', 'f2be5db5f3a210077e288f944b6e0fee.jpg', 'kyiv.jpg', NULL, '2015-02-15 21:33:12', '2015-02-15 21:33:12', 8180);


--
-- Name: ani_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_files_id_seq', 167, true);


--
-- Data for Name: ani_media_types; Type: TABLE DATA; Schema: public; Owner: anicrm
--

INSERT INTO ani_media_types VALUES (1, 'Телефон', 'phone');
INSERT INTO ani_media_types VALUES (7, 'Skype', 'messenger');
INSERT INTO ani_media_types VALUES (8, 'Email', 'email');
INSERT INTO ani_media_types VALUES (25, 'Рабочий Email', 'email');
INSERT INTO ani_media_types VALUES (16, 'Раб телефон', 'phone');
INSERT INTO ani_media_types VALUES (27, 'ICQ', 'messenger');
INSERT INTO ani_media_types VALUES (32, 'Viber', 'messenger');
INSERT INTO ani_media_types VALUES (26, 'Дом телефон', 'phone');


--
-- Name: ani_media_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_media_types_id_seq', 34, true);


--
-- Data for Name: ani_messengers; Type: TABLE DATA; Schema: public; Owner: anicrm
--

INSERT INTO ani_messengers VALUES (1, 'damian.hello', 7, 7465);
INSERT INTO ani_messengers VALUES (182, 'damian.hello', 7, 7755);
INSERT INTO ani_messengers VALUES (185, 'ыва', 7, 8139);
INSERT INTO ani_messengers VALUES (126, '1234567', 7, 8036);
INSERT INTO ani_messengers VALUES (131, 'aaaa', 7, 8096);
INSERT INTO ani_messengers VALUES (75, 'damian.hello', 7, 7473);
INSERT INTO ani_messengers VALUES (76, '1234567', 32, 7473);
INSERT INTO ani_messengers VALUES (213, 'asdasd', 7, 7482);
INSERT INTO ani_messengers VALUES (47, 'damian.hello', 7, 7825);
INSERT INTO ani_messengers VALUES (48, 'damian.hello', 7, 7829);
INSERT INTO ani_messengers VALUES (49, 'damian.hello', 7, 7832);
INSERT INTO ani_messengers VALUES (50, 'damian.hello', 7, 7835);
INSERT INTO ani_messengers VALUES (51, 'damian.hello', 7, 7838);
INSERT INTO ani_messengers VALUES (52, 'damian.hello', 7, 7840);
INSERT INTO ani_messengers VALUES (169, 'adasdad', 7, 8106);
INSERT INTO ani_messengers VALUES (170, 'asdas', 7, 8106);
INSERT INTO ani_messengers VALUES (171, 'asdads', 7, 8106);
INSERT INTO ani_messengers VALUES (172, 'asdasd', 7, 8106);
INSERT INTO ani_messengers VALUES (117, '1313123123', 7, 7977);
INSERT INTO ani_messengers VALUES (118, 'adadads', 7, 7977);
INSERT INTO ani_messengers VALUES (173, 'asdadas', 7, 8106);
INSERT INTO ani_messengers VALUES (177, 'tess', 7, 8116);


--
-- Name: ani_messengers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_messengers_id_seq', 213, true);


--
-- Data for Name: ani_migrations; Type: TABLE DATA; Schema: public; Owner: anicrm
--

INSERT INTO ani_migrations VALUES ('2014_08_08_122502_create_contacts_table', 1);
INSERT INTO ani_migrations VALUES ('2015_01_15_124903_create_files_table', 2);
INSERT INTO ani_migrations VALUES ('2015_01_15_133251_update_files_table', 3);
INSERT INTO ani_migrations VALUES ('2015_01_21_150811_create_files_comment_field', 4);


--
-- Data for Name: ani_phones; Type: TABLE DATA; Schema: public; Owner: anicrm
--

INSERT INTO ani_phones VALUES (7444, '5655555', 1, 7443);
INSERT INTO ani_phones VALUES (7446, '12312', 1, 7445);
INSERT INTO ani_phones VALUES (7448, '0445648237', 26, 7447);
INSERT INTO ani_phones VALUES (7449, '0662404292', 16, 7447);
INSERT INTO ani_phones VALUES (7451, '0445648237', 26, 7450);
INSERT INTO ani_phones VALUES (7452, '0662404292', 16, 7450);
INSERT INTO ani_phones VALUES (7454, '0445648237', 26, 7453);
INSERT INTO ani_phones VALUES (7455, '0662404292', 16, 7453);
INSERT INTO ani_phones VALUES (7457, '0445648237', 26, 7456);
INSERT INTO ani_phones VALUES (7458, '0662404292', 16, 7456);
INSERT INTO ani_phones VALUES (7460, '0445648237', 26, 7459);
INSERT INTO ani_phones VALUES (7461, '0662404292', 16, 7459);
INSERT INTO ani_phones VALUES (7463, '0445648237', 26, 7462);
INSERT INTO ani_phones VALUES (7464, '0662404292', 16, 7462);
INSERT INTO ani_phones VALUES (7466, '0445648237', 26, 7465);
INSERT INTO ani_phones VALUES (7467, '0662404292', 16, 7465);
INSERT INTO ani_phones VALUES (7471, '12312', 1, 7470);
INSERT INTO ani_phones VALUES (8176, '380662404292', 1, 7482);
INSERT INTO ani_phones VALUES (8179, '24234234', 1, 8147);
INSERT INTO ani_phones VALUES (7486, '380662404292', 1, NULL);
INSERT INTO ani_phones VALUES (7488, '380662404292', 1, 7487);
INSERT INTO ani_phones VALUES (7490, '380662404292', 1, 7489);
INSERT INTO ani_phones VALUES (7492, '380662404292', 1, 7491);
INSERT INTO ani_phones VALUES (7494, '380662404292', 1, 7493);
INSERT INTO ani_phones VALUES (7496, '380662404292', 1, 7495);
INSERT INTO ani_phones VALUES (7498, '380662404292', 1, 7497);
INSERT INTO ani_phones VALUES (7501, '380662404292', 1, 7500);
INSERT INTO ani_phones VALUES (7506, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7507, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7508, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7509, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7510, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7511, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7512, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7513, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7514, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7515, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7516, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7517, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7518, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7519, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7520, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7521, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7522, '380662404292', 1, 7505);
INSERT INTO ani_phones VALUES (7524, '0662404292', 1, 7523);
INSERT INTO ani_phones VALUES (7525, '1111111', 1, 7523);
INSERT INTO ani_phones VALUES (7526, '0662404292', 1, 7523);
INSERT INTO ani_phones VALUES (7527, '1111111', 1, 7523);
INSERT INTO ani_phones VALUES (7528, '0662404292', 1, 7523);
INSERT INTO ani_phones VALUES (7529, '1111111', 1, 7523);
INSERT INTO ani_phones VALUES (7530, '0662404292', 1, 7523);
INSERT INTO ani_phones VALUES (7531, '1111111', 1, 7523);
INSERT INTO ani_phones VALUES (7532, '0662404292', 1, 7523);
INSERT INTO ani_phones VALUES (7533, '1111111', 1, 7523);
INSERT INTO ani_phones VALUES (7534, '0662404292', 1, 7523);
INSERT INTO ani_phones VALUES (7535, '1111111', 1, 7523);
INSERT INTO ani_phones VALUES (7753, '380662404292', 1, 7536);
INSERT INTO ani_phones VALUES (7754, '5451617', 26, 7536);
INSERT INTO ani_phones VALUES (8094, '123123123', 1, 8055);
INSERT INTO ani_phones VALUES (8095, '1231212312', 1, 8055);
INSERT INTO ani_phones VALUES (7826, '112233', 1, 7825);
INSERT INTO ani_phones VALUES (7827, '380662404292', 1, 7825);
INSERT INTO ani_phones VALUES (7830, '112233', 1, 7829);
INSERT INTO ani_phones VALUES (7831, '380662404292', 16, 7829);
INSERT INTO ani_phones VALUES (7833, '112233', 1, 7832);
INSERT INTO ani_phones VALUES (7834, '380662404292', 1, 7832);
INSERT INTO ani_phones VALUES (7836, '112233', 1, 7835);
INSERT INTO ani_phones VALUES (7837, '123123123', 1, 7835);
INSERT INTO ani_phones VALUES (7839, '112233', 1, 7838);
INSERT INTO ani_phones VALUES (7841, '112233', 1, 7840);
INSERT INTO ani_phones VALUES (8103, '1231213123121', 1, 8096);
INSERT INTO ani_phones VALUES (8104, '12313', 1, 8096);
INSERT INTO ani_phones VALUES (8105, '12312312', 1, 8096);
INSERT INTO ani_phones VALUES (7858, '111111', 1, 7484);
INSERT INTO ani_phones VALUES (8112, '123131123123', 1, 8106);
INSERT INTO ani_phones VALUES (8113, '123123', 1, 8106);
INSERT INTO ani_phones VALUES (8114, '123123123123', 1, 8106);
INSERT INTO ani_phones VALUES (8115, '1231231231', 1, 8106);
INSERT INTO ani_phones VALUES (8031, '380662404292', 1, 7977);
INSERT INTO ani_phones VALUES (8032, '1123456', 1, 7977);
INSERT INTO ani_phones VALUES (7940, '3806620', 1, 7900);
INSERT INTO ani_phones VALUES (7941, '123123', 1, 7900);
INSERT INTO ani_phones VALUES (8033, '380662404292', 16, 7977);
INSERT INTO ani_phones VALUES (8034, '044', 1, 7977);
INSERT INTO ani_phones VALUES (8035, '380662404292', 1, 7480);
INSERT INTO ani_phones VALUES (8120, '06623423423', 1, 8116);
INSERT INTO ani_phones VALUES (8122, '0506679090', 1, 8121);
INSERT INTO ani_phones VALUES (7950, '380662404292', 1, 7475);
INSERT INTO ani_phones VALUES (7952, '380662404292', 1, 7438);
INSERT INTO ani_phones VALUES (8123, '0506679091', 16, 8121);
INSERT INTO ani_phones VALUES (8125, '12312312', 1, 8124);
INSERT INTO ani_phones VALUES (8127, '0502083915', 1, 8126);
INSERT INTO ani_phones VALUES (8128, '0502083915', 16, 8126);
INSERT INTO ani_phones VALUES (7960, '0662404292', 1, 7953);
INSERT INTO ani_phones VALUES (8050, '5671313', 1, 8036);
INSERT INTO ani_phones VALUES (7965, '380662404292', 1, 7477);
INSERT INTO ani_phones VALUES (7966, '2423423423', 1, 7477);
INSERT INTO ani_phones VALUES (7972, '02', 1, 7971);
INSERT INTO ani_phones VALUES (7973, '03', 1, 7971);
INSERT INTO ani_phones VALUES (7975, '1231231', 16, 7974);
INSERT INTO ani_phones VALUES (8051, '04412312312', 1, 8036);
INSERT INTO ani_phones VALUES (7893, '380662404292', 1, 7473);
INSERT INTO ani_phones VALUES (7894, '0445648237', 16, 7473);
INSERT INTO ani_phones VALUES (7895, '380662404292', 26, 7473);
INSERT INTO ani_phones VALUES (7897, '380662404292', 1, 7896);
INSERT INTO ani_phones VALUES (7899, '3804412', 1, 7898);
INSERT INTO ani_phones VALUES (8052, '242234234', 1, 8036);
INSERT INTO ani_phones VALUES (8137, '112233', 1, 7755);
INSERT INTO ani_phones VALUES (8138, '380662404292', 1, 7755);
INSERT INTO ani_phones VALUES (8142, '2424242', 1, 8139);
INSERT INTO ani_phones VALUES (8145, '1111111', 1, 8143);


--
-- Name: ani_phones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_phones_id_seq', 1, false);


--
-- Name: ani_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_contacts
    ADD CONSTRAINT ani_contacts_pkey PRIMARY KEY (id);


--
-- Name: ani_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_emails
    ADD CONSTRAINT ani_emails_pkey PRIMARY KEY (id);


--
-- Name: ani_files_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_files
    ADD CONSTRAINT ani_files_pkey PRIMARY KEY (id);


--
-- Name: ani_media_types_id_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_media_types
    ADD CONSTRAINT ani_media_types_id_pkey PRIMARY KEY (id);


--
-- Name: ani_messengers_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_messengers
    ADD CONSTRAINT ani_messengers_pkey PRIMARY KEY (id);


--
-- Name: phones_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_phones
    ADD CONSTRAINT phones_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

