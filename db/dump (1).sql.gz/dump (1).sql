--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: mediatypes; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE mediatypes AS ENUM (
    'phone',
    'messenger',
    'email'
);


ALTER TYPE public.mediatypes OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ani_contacts; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_contacts (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    responsible_id integer,
    "position" character varying(128),
    company_id integer
);


ALTER TABLE public.ani_contacts OWNER TO anicrm;

--
-- Name: ani_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_contacts_id_seq OWNER TO anicrm;

--
-- Name: ani_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anicrm
--

ALTER SEQUENCE ani_contacts_id_seq OWNED BY ani_contacts.id;


--
-- Name: ani_emails_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_emails_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_emails_id_seq OWNER TO anicrm;

--
-- Name: ani_emails; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_emails (
    id integer DEFAULT nextval('ani_emails_id_seq'::regclass) NOT NULL,
    email character varying(128) NOT NULL,
    media_type_id integer NOT NULL,
    contact_id integer
);


ALTER TABLE public.ani_emails OWNER TO anicrm;

--
-- Name: ani_files; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_files (
    id integer NOT NULL,
    size integer NOT NULL,
    content_type character varying(255),
    subdir character varying(255),
    name character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    description character varying(512),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    contact_id integer
);


ALTER TABLE public.ani_files OWNER TO anicrm;

--
-- Name: ani_files_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_files_id_seq OWNER TO anicrm;

--
-- Name: ani_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anicrm
--

ALTER SEQUENCE ani_files_id_seq OWNED BY ani_files.id;


--
-- Name: ani_media_types_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_media_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_media_types_id_seq OWNER TO anicrm;

--
-- Name: ani_media_types; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_media_types (
    id integer DEFAULT nextval('ani_media_types_id_seq'::regclass) NOT NULL,
    name character varying(128) NOT NULL,
    type mediatypes NOT NULL
);


ALTER TABLE public.ani_media_types OWNER TO anicrm;

--
-- Name: ani_messengers_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_messengers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_messengers_id_seq OWNER TO anicrm;

--
-- Name: ani_messengers; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_messengers (
    id integer DEFAULT nextval('ani_messengers_id_seq'::regclass) NOT NULL,
    value character varying(128) NOT NULL,
    media_type_id integer NOT NULL,
    contact_id integer
);


ALTER TABLE public.ani_messengers OWNER TO anicrm;

--
-- Name: ani_migrations; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_migrations (
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.ani_migrations OWNER TO anicrm;

--
-- Name: ani_phones; Type: TABLE; Schema: public; Owner: anicrm; Tablespace: 
--

CREATE TABLE ani_phones (
    id integer DEFAULT nextval('ani_contacts_id_seq'::regclass) NOT NULL,
    phone character varying(64) NOT NULL,
    media_type_id integer NOT NULL,
    contact_id integer
);


ALTER TABLE public.ani_phones OWNER TO anicrm;

--
-- Name: ani_phones_id_seq; Type: SEQUENCE; Schema: public; Owner: anicrm
--

CREATE SEQUENCE ani_phones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ani_phones_id_seq OWNER TO anicrm;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: anicrm
--

ALTER TABLE ONLY ani_contacts ALTER COLUMN id SET DEFAULT nextval('ani_contacts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: anicrm
--

ALTER TABLE ONLY ani_files ALTER COLUMN id SET DEFAULT nextval('ani_files_id_seq'::regclass);


--
-- Data for Name: ani_contacts; Type: TABLE DATA; Schema: public; Owner: anicrm
--

COPY ani_contacts (id, user_id, name, created_at, updated_at, responsible_id, "position", company_id) FROM stdin;
7482	\N	Дорофеев Андрей Николаевич	2015-01-22 16:07:26	2015-01-22 16:07:26	1	Программист	\N
7485	\N	Дорофеев Андрей Николаевич	2015-01-22 16:08:18	2015-01-22 16:08:18	1	Программист	\N
7487	\N	Дорофеев Андрей Николаевич	2015-01-22 16:08:48	2015-01-22 16:08:48	1	Программист	\N
7489	\N	Дорофеев Андрей Николаевич	2015-01-22 16:09:18	2015-01-22 16:09:18	1	Программист	\N
7491	\N	Дорофеев Андрей Николаевич	2015-01-22 16:10:04	2015-01-22 16:10:04	1	Программист	\N
7493	\N	Дорофеев Андрей Николаевич	2015-01-22 16:11:18	2015-01-22 16:11:18	1	Программист	\N
7495	\N	Дорофеев Андрей Николаевич	2015-01-22 16:47:55	2015-01-22 16:47:55	1	Программист	\N
7497	\N	Дорофеев Андрей Николаевич	2015-01-22 16:50:22	2015-01-22 16:50:22	1	Программист	\N
7499	\N	Дорофеев Андрей Николаевич	2015-01-22 16:51:25	2015-01-22 16:51:25	1	Программист	\N
7500	\N	Дорофеев Андрей Николаевич	2015-01-22 16:51:40	2015-01-22 16:51:40	1	Программист	\N
7502	\N	Дорофеев Андрей Николаевич	2015-01-22 16:51:59	2015-01-22 16:51:59	1	Программист	\N
7503	\N	Дорофеев Андрей Николаевич	2015-01-22 16:52:20	2015-01-22 16:52:20	1	Программист	\N
7504	\N	Дорофеев Андрей Николаевич	2015-01-22 16:52:54	2015-01-22 16:52:54	1	Программист	\N
7505	\N	Евгений Петрович	2015-01-22 17:01:37	2015-01-22 17:10:22	1	Программист	\N
7523	\N	Тест	2015-01-22 18:54:39	2015-01-22 18:54:39	1	Тест	\N
7896	\N	Петрушка	2015-01-26 13:39:24	2015-01-26 13:39:24	2	Никто	\N
7536	\N	Коломойский И.	2015-01-23 13:45:20	2015-01-23 17:11:18	12	Олигарх	\N
7898	\N	Петруха	2015-01-26 13:40:37	2015-01-26 13:40:37	\N		\N
7900	\N	Петруха	2015-01-26 13:49:40	2015-01-26 13:49:40	\N		\N
7475	\N	Дорофеев Андрей Николаевич	2015-01-22 15:57:56	2015-01-26 15:31:55	\N	Программист	\N
7825	\N	Дорофеев Андрей Николаевич	2015-01-26 09:56:07	2015-01-26 09:56:07	\N	Программист	\N
7828	\N	Дорофеев Андрей Николаевич	2015-01-26 09:56:07	2015-01-26 09:56:07	\N	Программист	\N
7829	\N	Дорофеев Андрей Николаевич	2015-01-26 09:56:52	2015-01-26 09:56:52	\N	Программист	\N
7832	\N	Дорофеев Андрей Николаевич	2015-01-26 09:59:02	2015-01-26 09:59:02	\N	Программист	\N
7835	\N	Дорофеев Андрей Николаевич	2015-01-26 10:00:13	2015-01-26 10:00:13	\N	Программист	\N
7838	\N	Дорофеев Андрей Николаевич	2015-01-26 10:00:57	2015-01-26 10:00:57	\N	Программис	\N
7840	\N	Дорофеев Андрей Николаевич	2015-01-26 10:01:24	2015-01-26 10:01:24	\N	Программист	\N
7755	\N	Дорофеев Андрей Николаевич	2015-01-23 18:27:12	2015-01-26 10:02:09	\N	Программист	\N
7484	\N	Дорофеев Андрей Николаевич	2015-01-22 16:07:35	2015-01-26 10:49:01	\N	Программист	\N
7472	\N	Дорофеев Андрей Николаевич	2015-01-22 15:49:29	2015-01-26 10:49:31	\N	Программист	\N
7951	\N	Дороф	2015-01-26 16:17:17	2015-01-26 16:17:17	\N		\N
7438	\N	Andrew	2014-10-27 18:06:09	2015-01-26 16:19:40	\N	agent	\N
7473	\N	Дорофеев Андрей Николаевич	2015-01-22 15:51:01	2015-01-26 11:39:14	\N	Программист	\N
8139	\N	Тест	2015-01-27 18:30:19	2015-01-27 18:30:19	\N	Машинист	\N
8143	\N	Новый контакт	2015-01-28 19:22:36	2015-01-28 19:22:36	\N	Механие	\N
7953	\N	Андрей	2015-01-26 16:20:04	2015-01-26 16:31:15	\N	Ктототам	\N
7477	\N	Дорофеев Андрей Николаевич	2015-01-22 16:03:36	2015-01-26 16:40:20	\N	Программист	\N
7967	\N	Паша	2015-01-26 16:44:36	2015-01-26 16:44:36	\N		\N
7968	\N	Афанасий	2015-01-26 16:46:35	2015-01-26 16:46:35	\N		\N
7969	\N	Афанасий	2015-01-26 16:49:10	2015-01-26 16:49:10	\N		\N
7970	\N	Афанасий	2015-01-26 16:49:26	2015-01-26 16:49:26	\N		\N
7971	\N	Валентин Игнатьевич	2015-01-26 16:58:27	2015-01-26 16:58:27	\N	Менеджер	\N
7479	\N	Дорофеев Андрей Николаевич	2015-01-22 16:06:06	2015-01-26 16:59:17	\N	Программист	\N
7974	\N	Тест	2015-01-26 17:05:06	2015-01-26 17:05:06	\N		\N
7976	\N	фывфывфывыв	2015-01-26 17:08:52	2015-01-26 17:08:52	\N		\N
7977	\N	Петрович	2015-01-26 17:31:15	2015-01-26 17:31:15	\N	Сантехник	\N
7480	\N	Дорофеев Андрей Николаевич	2015-01-22 16:07:15	2015-01-27 08:52:32	\N	Программист	\N
8036	\N	Буранов Олег	2015-01-27 08:54:16	2015-01-27 08:54:16	\N	Тестировщик	\N
8053	\N	13123123	2015-01-27 08:59:11	2015-01-27 08:59:11	\N		\N
8054	\N	113	2015-01-27 09:06:26	2015-01-27 09:06:26	\N		\N
8055	\N	113123131	2015-01-27 09:14:04	2015-01-27 09:16:21	\N		\N
8096	\N	asdasda	2015-01-27 11:00:19	2015-01-27 11:00:19	\N	adasd	\N
8106	\N	adada	2015-01-27 11:01:30	2015-01-27 11:20:43	\N	asdaa	\N
8116	\N	Дюжев Дмитрий	2015-01-27 11:21:33	2015-01-27 11:21:33	\N	Актер	\N
8121	\N	Александр Артемов	2015-01-27 14:52:39	2015-01-27 14:52:39	\N	директор	\N
8124	\N	asdasds	2015-01-27 15:07:10	2015-01-27 15:07:10	\N		\N
8126	\N	Арутюнян Артем	2015-01-27 15:20:57	2015-01-27 15:20:57	\N		\N
8177	\N	asdasda	2015-02-02 15:17:22	2015-02-02 15:18:05	2		\N
8147	\N	Миша1	2015-01-29 10:43:53	2015-02-02 15:18:21	\N		\N
8180	\N	12312	2015-02-15 21:33:10	2015-02-15 21:33:10	\N		\N
\.


--
-- Name: ani_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_contacts_id_seq', 8180, true);


--
-- Data for Name: ani_emails; Type: TABLE DATA; Schema: public; Owner: anicrm
--

COPY ani_emails (id, email, media_type_id, contact_id) FROM stdin;
1	andrew.dorofeev@aniart.com.ua	25	7465
2	damianwnet@gmail.com	8	7465
3	damianwnet@gmail.com	8	7505
4	andrew.dorofeev@gmail.com	8	7505
5	damianwnet@gmail.com	8	7505
6	andrew.dorofeev@gmail.com	8	7505
7	damianwnet@gmail.com	8	7505
8	andrew.dorofeev@gmail.com	8	7505
9	damianwnet@gmail.com	8	7505
10	andrew.dorofeev@gmail.com	8	7505
11	damianwnet@gmail.com	8	7505
12	andrew.dorofeev@gmail.com	8	7505
13	damianwnet@gmail.com	8	7505
14	andrew.dorofeev@gmail.com	8	7505
15	damianwnet@gmail.com	8	7505
16	andrew.dorofeev@gmail.com	8	7505
17	damianwnet@gmail.com	8	7505
18	andrew.dorofeev@gmail.com	8	7505
19	damianwnet@gmail.com	8	7505
20	andrew.dorofeev@gmail.com	8	7505
21	damianwnet@gmail.com	8	7505
22	andrew.dorofeev@gmail.com	8	7505
23	damianwnet@gmail.com	8	7505
24	andrew.dorofeev@gmail.com	8	7505
25	damianwnet@gmail.com	8	7505
26	andrew.dorofeev@gmail.com	8	7505
27	damianwnet@gmail.com	8	7505
28	andrew.dorofeev@gmail.com	8	7505
29	damianwnet@gmail.com	8	7505
30	andrew.dorofeev@gmail.com	8	7505
31	damianwnet@gmail.com	8	7505
32	andrew.dorofeev@gmail.com	8	7505
33	damianwnet@gmail.com	8	7505
34	andrew.dorofeev@gmail.com	8	7505
35	damianwnet@gmail.com	8	7505
36	andrew.dorofeev@gmail.com	8	7505
37	damianwnet@gmail.com	8	7523
38	damianwnet@gmail.com	8	7523
39	damianwnet@gmail.com	8	7523
40	damianwnet@gmail.com	8	7523
41	damianwnet@gmail.com	8	7523
42	damianwnet@gmail.com	8	7523
256	test@test.ua	25	8143
107	damiwnet@gmail.com	8	7825
108	damiwnet@gmail.com	8	7829
109	damiwnet@gmail.com	8	7832
110	andrew.dorofeev@gmail.com	8	7832
111	damiwnet@gmail.com	8	7835
112	damiwnet@gmail.com	8	7838
113	damiwnet@gmail.com	8	7840
58	damianwnet@gmail.com	8	7536
266	test@test.tes	8	7482
200	test@test.ua	8	7977
201	aaa@aa.ua	8	7977
137	damianwnet@gmail.com	8	7473
138	test@test.test	8	7896
216	test@test.test	8	8036
217	test@test1.test	8	8036
156	damianwnet@gmail.com	8	7900
157	a@test.ua	8	7971
226	asdasd@adasd.test	8	8055
230	aaa@aa.ua	8	8096
234	damianwnet@gmail.com	8	8106
235	test@test.ua	8	8106
239	aaa@aa.aa	8	8116
240	avdov@narod.ru	8	8121
241	managers@aniart.com.ua	8	8126
250	damiwnet@gmail.com	8	7755
251	andrew.dorofeev@gmail.com	8	7755
254	ea@aa.aa	8	8139
\.


--
-- Name: ani_emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_emails_id_seq', 266, true);


--
-- Data for Name: ani_files; Type: TABLE DATA; Schema: public; Owner: anicrm
--

COPY ani_files (id, size, content_type, subdir, name, original_name, description, created_at, updated_at, contact_id) FROM stdin;
1	38081	application/xml	a76	319de9e4218c6ea5946d59e3ceafe7b9.xls	a76beca8788fcdc7a81627b6458c1e1f.xls	\N	2015-01-19 17:36:17	2015-01-19 17:36:17	\N
2	38081	application/xml	135	a44ce52e7ddc28e61481ce6286cc3d56.xls	135fd655a79f2f802afe7e5f4517adad.xls	\N	2015-01-19 18:08:18	2015-01-19 18:08:18	\N
3	3208	image/gif	5a6	5a6aaa2196fe721deb77b3d1bb4b3583.gif	ajax-loader.gif	\N	2015-01-19 18:22:08	2015-01-19 18:22:08	\N
4	1039	text/plain	b31	b31081592542b85086224abed0e36c0c.csv	example_contacts_ru.csv	\N	2015-01-19 18:23:17	2015-01-19 18:23:17	\N
5	38081	application/xml	67e	67e36f74015ced04710e5229be9fd24c.xls	advertisement.xls	\N	2015-01-19 18:37:41	2015-01-19 18:37:41	\N
6	38081	application/xml	803	803128f9d01353b111b764b2af4141c6.xls	advertisement.xls	\N	2015-01-19 18:44:51	2015-01-19 18:44:51	\N
7	38081	application/xml	c09	c09e0d597713d185a7a1693254456f5d.xls	advertisement.xls	\N	2015-01-20 06:56:58	2015-01-20 06:56:58	\N
8	1163	image/png	da5	da59d1bae58dfbcfb6d08a4bef940252.png	7.png	\N	2015-01-26 07:47:14	2015-01-26 07:47:14	\N
9	395750	image/png	551	551119fcdd4355907aa4cb2d24c885be.png	75553206.png	\N	2015-01-26 07:47:14	2015-01-26 07:47:14	\N
10	1163	image/png	164	164b0711670cc2bd3c248497f60a9d07.png	7.png	\N	2015-01-26 08:11:50	2015-01-26 08:11:50	\N
11	395750	image/png	cda	cdaba1355d2cd85549a0f20192321f0c.png	75553206.png	\N	2015-01-26 08:11:50	2015-01-26 08:11:50	\N
12	1163	image/png	e14	e14bc4761ca66a10bd5516f420f420bb.png	7.png	\N	2015-01-26 08:12:07	2015-01-26 08:12:07	\N
13	395750	image/png	504	504144a23dd8755c6c9e712f5ba2b80a.png	75553206.png	\N	2015-01-26 08:12:07	2015-01-26 08:12:07	\N
14	1163	image/png	e75	e758f7888507f09c99549ba1a7fc4942.png	7.png	\N	2015-01-26 08:14:43	2015-01-26 08:14:43	\N
15	395750	image/png	448	448994aecd787f8553320efa8e9918a7.png	75553206.png	\N	2015-01-26 08:14:43	2015-01-26 08:14:43	\N
16	1163	image/png	22e	22e04a05ad893aaf808c40cda75b700c.png	7.png	\N	2015-01-26 08:25:40	2015-01-26 08:25:40	\N
17	395750	image/png	696	6960edc31a3298b61dcdd3393fa38c75.png	75553206.png	\N	2015-01-26 08:25:40	2015-01-26 08:25:40	\N
18	1163	image/png	3ca	3ca9ffd051cbe145af000b5c99af8923.png	7.png	\N	2015-01-26 08:26:20	2015-01-26 08:26:20	\N
19	395750	image/png	abb	abbc0f4af51c1881c3c51efefd79be19.png	75553206.png	\N	2015-01-26 08:26:21	2015-01-26 08:26:21	\N
44	22370	text/plain	3c7	3c7a935b88319d9b54dcd9c92fae1647.csv	contacts.csv	\N	2015-01-26 11:33:03	2015-01-26 11:33:04	7473
22	3208	image/gif	979	9792bfa0ff8958fca3a086f996a49a88.gif	ajax-loader.gif	\N	2015-01-26 08:42:07	2015-01-26 08:42:07	\N
23	1163	image/png	b3f	b3fcfd07fe564389f0980930f8059aad.png	7.png	\N	2015-01-26 08:46:36	2015-01-26 08:46:36	\N
24	3208	image/gif	8de	8de899d7e07079a869bdc97de6089616.gif	ajax-loader.gif	\N	2015-01-26 08:54:26	2015-01-26 08:54:26	\N
25	3208	image/gif	f69	f6970f511f8415f062daaf7475617590.gif	ajax-loader.gif	\N	2015-01-26 09:21:19	2015-01-26 09:21:19	\N
26	3208	image/gif	399	399783d88f5fabcc45b25978cb40436d.gif	ajax-loader.gif	\N	2015-01-26 09:22:53	2015-01-26 09:22:53	\N
27	3208	image/gif	ba7	ba71207f0ef61a4734d14b392a23926e.gif	ajax-loader.gif	\N	2015-01-26 09:30:53	2015-01-26 09:30:53	\N
28	3208	image/gif	494	494620f8374fc20b84955a27cce1fa3d.gif	ajax-loader.gif	\N	2015-01-26 09:31:57	2015-01-26 09:31:57	\N
29	3208	image/gif	536	536533d5790bc10e0a0e112c6a1c4ad8.gif	ajax-loader.gif	\N	2015-01-26 09:45:28	2015-01-26 09:45:28	\N
20	1163	image/png	b62	b620588c8517561848ede78fa99258ce.png	7.png	\N	2015-01-26 08:28:24	2015-01-26 09:56:07	7825
21	395750	image/png	f97	f97fa653d0c428a74871d3d9e682dd0d.png	75553206.png	\N	2015-01-26 08:28:25	2015-01-26 09:56:07	7825
30	3208	image/gif	f33	f33b54964f89c98868b652a798d86aa6.gif	ajax-loader.gif	\N	2015-01-26 09:56:07	2015-01-26 09:56:07	7828
31	1163	image/png	02a	02a83ab07558109239a4464829e80508.png	7.png	\N	2015-01-26 10:03:23	2015-01-26 10:03:23	\N
32	395750	image/png	55f	55f379549d4c491b48a4ac6da43cd7f0.png	75553206.png	\N	2015-01-26 10:03:24	2015-01-26 10:03:24	\N
33	1163	image/png	404	40404c09e8f6c08398ba66b0a4fdbbef.png	7.png	\N	2015-01-26 10:15:41	2015-01-26 10:15:41	\N
34	395750	image/png	c0c	c0cf97604d4e1db2966e1df8d3ae97a0.png	75553206.png	\N	2015-01-26 10:15:42	2015-01-26 10:15:42	\N
39	1163	image/png	705	7051d7c9c2ab5ac38af38b67432f7c42.png	7.png	\N	2015-01-26 10:53:59	2015-01-26 10:53:59	7473
40	395750	image/png	676	676e0c21e07bc286fa882d1ef5eeef54.png	75553206.png	\N	2015-01-26 10:54:40	2015-01-26 10:54:40	7473
41	395750	image/png	b6a	b6abe9a85f1d38da395096dbc31ac015.png	75553206.png	\N	2015-01-26 10:54:50	2015-01-26 10:54:50	7473
42	1163	image/png	334	334248f2ad12f6e8adf72d3404fbfcfb.png	7.png	\N	2015-01-26 10:57:11	2015-01-26 10:57:12	7473
43	127294	text/x-c++	987	9876b35a3900f3a84519727195401a48.php	bx_1c_import.php	\N	2015-01-26 11:22:11	2015-01-26 11:22:11	7473
45	1163	image/png	13c	13c889b344dd9ec2a518ab661983c558.png	7.png	\N	2015-01-26 13:54:04	2015-01-26 13:54:04	\N
46	1163	image/png	23e	23e3e6208e0eb9c4f18053a686605a28.png	7.png	\N	2015-01-26 13:55:15	2015-01-26 13:55:15	\N
47	1163	image/png	b0f	b0ffdaaea730a0753fc97292edca82f6.png	7.png	\N	2015-01-26 13:56:53	2015-01-26 13:56:53	\N
48	1163	image/png	b17	b170b2ee3b83a400290c13278e1202dd.png	7.png	\N	2015-01-26 13:58:59	2015-01-26 13:58:59	\N
49	1163	image/png	d76	d768a916deb034eb8da68fc49f1c56e4.png	7.png	\N	2015-01-26 14:16:24	2015-01-26 14:16:24	\N
50	1163	image/png	433	4339088f2f96a2c3718fa88fa9bb5745.png	7.png	\N	2015-01-26 14:51:44	2015-01-26 14:51:44	\N
51	395750	image/png	a19	a194dc3faca07c3eda85aca4cde9056d.png	75553206.png	\N	2015-01-26 14:51:45	2015-01-26 14:51:45	\N
52	1163	image/png	c07	c0701249f33e013c5c8e5f3cd85aa59e.png	7.png	\N	2015-01-26 14:54:58	2015-01-26 14:54:58	\N
53	1163	image/png	d49	d49dbad135c10b71d90d886db858df5f.png	7.png	\N	2015-01-26 15:11:04	2015-01-26 15:11:04	\N
54	395750	image/png	ad5	ad5390bf0df290cfecf49e053382c9a3.png	75553206.png	\N	2015-01-26 15:16:05	2015-01-26 15:16:05	\N
55	1163	image/png	ac7	ac7e237414806747dcf9df68a18458dd.png	7.png	\N	2015-01-26 15:16:46	2015-01-26 15:16:46	\N
56	1163	image/png	fea	fea8f2f4136ec5a6d4ceafacbf96f0d2.png	7.png	\N	2015-01-26 15:17:13	2015-01-26 15:17:14	7900
57	3208	image/gif	c5b	c5bf9031439fa25d62730935b324a158.gif	ajax-loader.gif	\N	2015-01-26 15:17:13	2015-01-26 15:17:14	7900
58	395750	image/png	e96	e9647bf07aae7b7d66fc3e5dedcbf120.png	75553206.png	\N	2015-01-26 15:17:13	2015-01-26 15:17:14	7900
59	38081	application/xml	ddc	ddcb7929bd4ed5048998c4b6dc4a8aec.xls	advertisement.xls	\N	2015-01-26 15:17:14	2015-01-26 15:17:14	7900
60	1163	image/png	b8d	b8dabad577e7cd712030fb9d7ab53143.png	7.png	\N	2015-01-26 15:17:43	2015-01-26 15:17:43	7900
61	395750	image/png	18f	18fc2737921357a504ff49df79af7018.png	75553206.png	\N	2015-01-26 15:18:15	2015-01-26 15:18:15	7900
62	38081	application/xml	7b6	7b68e048fcb79cd0da9e608445b3077d.xls	advertisement.xls	\N	2015-01-26 15:18:28	2015-01-26 15:18:28	7900
63	1163	image/png	f41	f41d5102bcc45e636422c2b9a36dc18d.png	7.png	\N	2015-01-26 15:20:22	2015-01-26 15:20:22	7900
64	1163	image/png	e4b	e4bfa425edb87b7437a769d03020e8a2.png	7.png	\N	2015-01-26 15:21:37	2015-01-26 15:21:37	7900
65	127294	text/x-c++	4e8	4e88489ec75137fc705ddab71b381f7f.php	bx_1c_import.php	\N	2015-01-26 15:22:55	2015-01-26 15:22:55	7900
66	1163	image/png	7c6	7c6ea61531d15f6358511b20b9456739.png	7.png	\N	2015-01-26 15:24:03	2015-01-26 15:24:03	7900
67	1163	image/png	84a	84a1d86e53892370db413ef4211b2d43.png	7.png	\N	2015-01-26 15:26:34	2015-01-26 15:26:34	\N
68	1163	image/png	69a	69ac85b55ad944528621c7a3762158f9.png	7.png	\N	2015-01-26 15:27:09	2015-01-26 15:27:09	\N
69	1163	image/png	369	369056fd9714d9b5bf2e2e03cee24dd5.png	7.png	\N	2015-01-26 15:30:33	2015-01-26 15:30:33	\N
70	3208	image/gif	cbc	cbc77c932f293baf743d4498fcfc701e.gif	ajax-loader.gif	\N	2015-01-26 15:31:01	2015-01-26 15:31:01	\N
71	1163	image/png	acc	acca427e932c2604e7f306eda07065fb.png	7.png	\N	2015-01-26 15:32:27	2015-01-26 15:32:27	\N
72	1163	image/png	70f	70fa8466d15b7f43e97416d62a9f010e.png	7.png	\N	2015-01-26 15:33:57	2015-01-26 15:33:57	\N
73	1163	image/png	006	0062f85c7d62816d3f05560118044e5a.png	7.png	\N	2015-01-26 15:36:06	2015-01-26 15:36:06	7475
74	395750	image/png	951	95186193031275b7bd5c0e8600664c76.png	75553206.png	\N	2015-01-26 15:37:22	2015-01-26 15:37:22	7475
75	38081	application/xml	77a	77ae018b5a12f6c4edd9656a2e13176d.xls	advertisement.xls	\N	2015-01-26 15:39:02	2015-01-26 15:39:02	7475
76	1163	image/png	f1b	f1bb97c5b5e1e3ff5522d4f86e908188.png	7.png	\N	2015-01-26 15:43:03	2015-01-26 15:43:03	7475
77	1163	image/png	7b2	7b274d5a6f03ba1eb9f32388c26e9340.png	7.png	\N	2015-01-26 15:47:48	2015-01-26 15:47:48	7475
78	3208	image/gif	fed	fed4b2a22b7e8abef9c7897fe6f1b154.gif	ajax-loader.gif	\N	2015-01-26 15:49:36	2015-01-26 15:49:37	7475
79	1163	image/png	68e	68e691cafe95647718433407e9fa05a2.png	7.png	\N	2015-01-26 16:20:18	2015-01-26 16:20:19	7953
80	395750	image/png	84f	84f26b17844de4773fe32501cc5da68f.png	75553206.png	\N	2015-01-26 16:20:19	2015-01-26 16:20:19	7953
81	1163	image/png	885	885e2793f19c4815cea6f76f8fe08977.png	7.png	\N	2015-01-26 16:31:15	2015-01-26 16:31:15	7953
82	395750	image/png	a9f	a9fe36055c900e6d2c1c929a64294379.png	75553206.png	\N	2015-01-26 16:31:15	2015-01-26 16:31:15	7953
83	1163	image/png	9fc	9fc49620ebb41d39354a95fb6146c07a.png	7.png	\N	2015-01-26 16:40:30	2015-01-26 16:40:31	7477
84	395750	image/png	0c6	0c6070361a78d70588fff8248701c26b.png	75553206.png	\N	2015-01-26 16:40:31	2015-01-26 16:40:31	7477
85	1163	image/png	7f2	7f2c2513c28a85f4600ccc159d6d1883.png	7.png	\N	2015-01-26 16:41:27	2015-01-26 16:41:27	7477
86	1163	image/png	e61	e6167675eb9fb739b2b5fd5728a62d23.png	7.png	\N	2015-01-26 16:44:36	2015-01-26 16:44:36	\N
87	395750	image/png	950	9509b216341dc1d74757bfd3136ddc20.png	75553206.png	\N	2015-01-26 16:44:36	2015-01-26 16:44:36	\N
88	1163	image/png	c99	c9915c90b88ed7331bc564e0a41baae5.png	7.png	\N	2015-01-26 16:58:27	2015-01-26 16:58:27	\N
89	395750	image/png	81a	81a1ec1da432dffe200738449879150c.png	75553206.png	\N	2015-01-26 16:58:28	2015-01-26 16:58:28	\N
90	1163	image/png	595	5951c88522100fa9e86a105bfbe2a8e6.png	7.png	\N	2015-01-26 16:59:17	2015-01-26 16:59:17	\N
91	395750	image/png	2fd	2fd087603593cd685e632897f799a401.png	75553206.png	\N	2015-01-26 16:59:18	2015-01-26 16:59:18	\N
92	1163	image/png	4a9	4a9de2713f2413ecd1346e9ec62c787c.png	7.png	\N	2015-01-26 17:05:06	2015-01-26 17:05:06	\N
93	395750	image/png	da3	da3f5691269a1eefa7aaf1f6951c4480.png	75553206.png	\N	2015-01-26 17:05:06	2015-01-26 17:05:06	\N
94	1163	image/png	b78	b78c083b1e8a3c98545d31022d4eec91.png	7.png	\N	2015-01-26 17:08:52	2015-01-26 17:08:52	\N
95	1163	image/png	c31	c31124d7dab228579b66473d2d7f070b.png	7.png	\N	2015-01-26 17:37:04	2015-01-26 17:37:05	7977
96	395750	image/png	c6b	c6ba6b2566db65524f1b1e45dd9854ed.png	75553206.png	\N	2015-01-26 17:37:04	2015-01-26 17:37:05	7977
97	3208	image/gif	1ce	1ce85a6d4e5b19b9b8ccd925e6d767f1.gif	ajax-loader.gif	\N	2015-01-26 17:51:49	2015-01-26 17:51:49	7977
98	3208	image/gif	bc9	bc91ceb709b9c0ced4d16f5150c2482e.gif	ajax-loader.gif	\N	2015-01-26 17:54:00	2015-01-26 17:54:00	7977
99	27890	application/pdf	a6e	a6ed52038322133bbe39eeababa0eb50.pdf	КБ46від24.07.2014_1_ід_35131.pdf	\N	2015-01-27 08:19:52	2015-01-27 08:19:52	7977
100	27890	application/pdf	415	415369dbc49537cba0b7f6ea062c2e89.pdf	КБ46від24.07.2014_1_ід_35131 (1).pdf	\N	2015-01-27 08:19:52	2015-01-27 08:19:52	7977
101	1163	image/png	32c	32ceec8b9842834f18be262f686ceff7.png	7.png	\N	2015-01-27 08:22:00	2015-01-27 08:22:16	7977
102	395750	image/png	67f	67f29dc7c51a78ff5de0c83c5a86e5ab.png	75553206.png	\N	2015-01-27 08:22:01	2015-01-27 08:22:16	7977
103	1163	image/png	d6d	d6d0138d2e0512758f1a4d0b9385a1ec.png	7.png	\N	2015-01-27 08:26:52	2015-01-27 08:26:52	\N
104	395750	image/png	c5f	c5fa4cf74d914bdca0d6ba5b22ea4424.png	75553206.png	\N	2015-01-27 08:26:52	2015-01-27 08:26:52	\N
105	1163	image/png	226	22635d95a63a2f48572b16a73245808c.png	7.png	\N	2015-01-27 08:32:27	2015-01-27 08:32:29	7977
106	1163	image/png	762	762cc4a8e54b9d14322fa6a24f288caa.png	7.png	\N	2015-01-27 08:44:08	2015-01-27 08:44:08	7977
107	66163	application/xml	f2e	f2e4b1ada2d2d7e8b77bd91c737d5ac0.xml	orders1251.xml	\N	2015-01-27 08:47:56	2015-01-27 08:47:56	\N
108	199378	image/jpeg	249	249312d3250b234d0e9fb585803bec42.jpg	orders1251.jpg	\N	2015-01-27 08:47:56	2015-01-27 08:47:56	\N
109	1163	image/png	6ab	6ab7350cd6e2426b4bd565f97bc078ec.png	7.png	\N	2015-01-27 08:52:32	2015-01-27 08:52:32	\N
110	1163	image/png	c46	c46f4dcddf88f310773cebd8eb068d68.png	7.png	\N	2015-01-27 08:54:16	2015-01-27 08:54:16	\N
111	38081	application/xml	6d0	6d0066f094fb634a0bccafd5806f75b0.xls	advertisement.xls	\N	2015-01-27 08:54:16	2015-01-27 08:54:16	\N
112	395750	image/png	4e1	4e1e402318d4c9842a0647f31b2d5424.png	75553206.png	\N	2015-01-27 08:54:17	2015-01-27 08:54:17	\N
113	1163	image/png	2e2	2e233b32af12bf97c606c53463fe00a6.png	7.png	\N	2015-01-27 08:56:56	2015-01-27 08:56:57	8036
114	395750	image/png	b09	b0969d6ad4708c596e8f5ef2c441b921.png	75553206.png	\N	2015-01-27 08:56:56	2015-01-27 08:56:57	8036
115	1163	image/png	d93	d932c37e0b981fd66ae884f2a5864406.png	7.png	\N	2015-01-27 08:59:11	2015-01-27 08:59:11	\N
116	1163	image/png	7f8	7f838d1e54010d3771db65b799f7e49a.png	7.png	\N	2015-01-27 09:06:55	2015-01-27 09:06:55	\N
117	1163	image/png	bdb	bdb719695265f57409652318a8393bc7.png	7.png	\N	2015-01-27 09:14:04	2015-01-27 09:14:05	8055
118	395750	image/png	f30	f30ee42665385ee44c50a31bc24eedd7.png	75553206.png	\N	2015-01-27 09:14:05	2015-01-27 09:14:05	8055
119	1163	image/png	fb3	fb3c2cd85aaa2f371eeb17e11ae54a9b.png	7.png	\N	2015-01-27 09:53:37	2015-01-27 09:53:38	8055
120	1163	image/png	33a	33a88f836eceb64c84b224db843889fd.png	7.png	\N	2015-01-27 11:00:19	2015-01-27 11:00:20	8096
121	395750	image/png	aef	aeff2580e8aa447095f4c89ba8c4a20f.png	75553206.png	\N	2015-01-27 11:00:19	2015-01-27 11:00:20	8096
122	1163	image/png	020	0200754a28f2fb2344bbbf0776e1d3ce.png	7.png	\N	2015-01-27 11:01:03	2015-01-27 11:01:03	8096
123	1163	image/png	279	2790c58bb7818481f26ac933e138a93b.png	7.png	\N	2015-01-27 11:14:38	2015-01-27 11:14:38	8106
124	3208	image/gif	f73	f731d343272bb2191e72799bdbde6ce1.gif	ajax-loader.gif	\N	2015-01-27 11:14:38	2015-01-27 11:14:38	8106
125	38081	application/xml	0f9	0f9ba2438c866db390a3013c7dcd9351.xls	advertisement.xls	\N	2015-01-27 11:14:38	2015-01-27 11:14:38	8106
126	395750	image/png	209	2093c9994e3dde768e67b60ca16f378d.png	75553206.png	\N	2015-01-27 11:14:38	2015-01-27 11:14:38	8106
127	64000	application/vnd.ms-excel	6f1	6f12a411ff50e5f7ce7084315e724be3.xls	{F94DC5FD-DDF0-4111-BDBA-C76D38D421A7}RUKAVYCHKA 1504.xls	\N	2015-01-27 11:20:44	2015-01-27 11:20:44	8106
150	1163	image/png	e0b	e0ba924b0563b77309bf2a154fad33c0.png	7.png	\N	2015-01-27 18:30:19	2015-01-27 18:30:20	8139
151	38081	application/xml	42f	42f6531fb27a97b8456a3e8ab54d3e6d.xls	advertisement.xls	\N	2015-01-27 18:30:19	2015-01-27 18:30:20	8139
133	38081	application/xml	8ba	8ba53405843fd1f5b272daf242da1f0d.xls	advertisement.xls	\N	2015-01-27 12:17:56	2015-01-27 12:17:56	8116
134	64698	image/jpeg	629	6294b4612f10036b4feb4245a9c510da.jpg	1389218067_poker.jpg	\N	2015-01-27 15:07:11	2015-01-27 15:07:11	8124
152	395750	image/png	b54	b543c4e573ae312b49e7575d7788f925.png	75553206.png	\N	2015-01-27 18:30:20	2015-01-27 18:30:20	8139
153	1163	image/png	170	170b9a6232b6d04481efa3201e78bdf1.png	7.png	\N	2015-01-28 09:27:19	2015-01-28 09:27:20	8139
154	395750	image/png	42f	42fe884694e6606e270e3955d864c46c.png	75553206.png	\N	2015-01-28 09:27:20	2015-01-28 09:27:20	8139
155	31664	image/jpeg	465	465b1db81ebe7a441419b2a14f693bc6.jpg	1329898353_andrey-yarmolenko.jpg	\N	2015-01-28 19:22:36	2015-01-28 19:22:38	8143
156	40231	image/jpeg	966	966182d80550c21ca6fc12b7753c37bf.jpg	lyric_girl.jpg	\N	2015-01-28 19:22:37	2015-01-28 19:22:38	8143
157	1163	image/png	3d8	3d8b716c7f15a22d6e845db7c1a1fe6a.png	7.png	\N	2015-01-29 10:43:53	2015-01-29 10:43:55	8147
158	38081	application/xml	6a3	6a36dd94bd54bcc4e4416a4aa45e70cb.xls	advertisement.xls	\N	2015-01-29 10:43:53	2015-01-29 10:43:55	8147
161	395750	image/png	fd8	fd823507b8ade34b92f93891fda6ca4c.png	75553206.png	\N	2015-01-31 14:14:12	2015-01-31 14:14:12	7482
162	38081	application/xml	1f0	1f0468aa4085b0b8e4bf5ef60b2f1647.xls	advertisement.xls	\N	2015-02-02 13:59:05	2015-02-02 13:59:05	\N
163	395750	image/png	f34	f342ac994bd9354445d2d8db84e51cc6.png	75553206.png	\N	2015-02-02 13:59:05	2015-02-02 13:59:05	\N
166	369028	image/jpeg	557	5577425cca4423ac060a4e9f9c6d0555.jpg	skopa2.jpg	\N	2015-02-15 21:33:11	2015-02-15 21:33:12	8180
167	352691	image/jpeg	f2b	f2be5db5f3a210077e288f944b6e0fee.jpg	kyiv.jpg	\N	2015-02-15 21:33:12	2015-02-15 21:33:12	8180
\.


--
-- Name: ani_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_files_id_seq', 167, true);


--
-- Data for Name: ani_media_types; Type: TABLE DATA; Schema: public; Owner: anicrm
--

COPY ani_media_types (id, name, type) FROM stdin;
1	Телефон	phone
7	Skype	messenger
8	Email	email
25	Рабочий Email	email
16	Раб телефон	phone
27	ICQ	messenger
32	Viber	messenger
26	Дом телефон	phone
\.


--
-- Name: ani_media_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_media_types_id_seq', 34, true);


--
-- Data for Name: ani_messengers; Type: TABLE DATA; Schema: public; Owner: anicrm
--

COPY ani_messengers (id, value, media_type_id, contact_id) FROM stdin;
1	damian.hello	7	7465
182	damian.hello	7	7755
185	ыва	7	8139
126	1234567	7	8036
131	aaaa	7	8096
75	damian.hello	7	7473
76	1234567	32	7473
213	asdasd	7	7482
47	damian.hello	7	7825
48	damian.hello	7	7829
49	damian.hello	7	7832
50	damian.hello	7	7835
51	damian.hello	7	7838
52	damian.hello	7	7840
169	adasdad	7	8106
170	asdas	7	8106
171	asdads	7	8106
172	asdasd	7	8106
117	1313123123	7	7977
118	adadads	7	7977
173	asdadas	7	8106
177	tess	7	8116
\.


--
-- Name: ani_messengers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_messengers_id_seq', 213, true);


--
-- Data for Name: ani_migrations; Type: TABLE DATA; Schema: public; Owner: anicrm
--

COPY ani_migrations (migration, batch) FROM stdin;
2014_08_08_122502_create_contacts_table	1
2015_01_15_124903_create_files_table	2
2015_01_15_133251_update_files_table	3
2015_01_21_150811_create_files_comment_field	4
\.


--
-- Data for Name: ani_phones; Type: TABLE DATA; Schema: public; Owner: anicrm
--

COPY ani_phones (id, phone, media_type_id, contact_id) FROM stdin;
7444	5655555	1	7443
7446	12312	1	7445
7448	0445648237	26	7447
7449	0662404292	16	7447
7451	0445648237	26	7450
7452	0662404292	16	7450
7454	0445648237	26	7453
7455	0662404292	16	7453
7457	0445648237	26	7456
7458	0662404292	16	7456
7460	0445648237	26	7459
7461	0662404292	16	7459
7463	0445648237	26	7462
7464	0662404292	16	7462
7466	0445648237	26	7465
7467	0662404292	16	7465
7471	12312	1	7470
8176	380662404292	1	7482
8179	24234234	1	8147
7486	380662404292	1	\N
7488	380662404292	1	7487
7490	380662404292	1	7489
7492	380662404292	1	7491
7494	380662404292	1	7493
7496	380662404292	1	7495
7498	380662404292	1	7497
7501	380662404292	1	7500
7506	380662404292	1	7505
7507	380662404292	1	7505
7508	380662404292	1	7505
7509	380662404292	1	7505
7510	380662404292	1	7505
7511	380662404292	1	7505
7512	380662404292	1	7505
7513	380662404292	1	7505
7514	380662404292	1	7505
7515	380662404292	1	7505
7516	380662404292	1	7505
7517	380662404292	1	7505
7518	380662404292	1	7505
7519	380662404292	1	7505
7520	380662404292	1	7505
7521	380662404292	1	7505
7522	380662404292	1	7505
7524	0662404292	1	7523
7525	1111111	1	7523
7526	0662404292	1	7523
7527	1111111	1	7523
7528	0662404292	1	7523
7529	1111111	1	7523
7530	0662404292	1	7523
7531	1111111	1	7523
7532	0662404292	1	7523
7533	1111111	1	7523
7534	0662404292	1	7523
7535	1111111	1	7523
7753	380662404292	1	7536
7754	5451617	26	7536
8094	123123123	1	8055
8095	1231212312	1	8055
7826	112233	1	7825
7827	380662404292	1	7825
7830	112233	1	7829
7831	380662404292	16	7829
7833	112233	1	7832
7834	380662404292	1	7832
7836	112233	1	7835
7837	123123123	1	7835
7839	112233	1	7838
7841	112233	1	7840
8103	1231213123121	1	8096
8104	12313	1	8096
8105	12312312	1	8096
7858	111111	1	7484
8112	123131123123	1	8106
8113	123123	1	8106
8114	123123123123	1	8106
8115	1231231231	1	8106
8031	380662404292	1	7977
8032	1123456	1	7977
7940	3806620	1	7900
7941	123123	1	7900
8033	380662404292	16	7977
8034	044	1	7977
8035	380662404292	1	7480
8120	06623423423	1	8116
8122	0506679090	1	8121
7950	380662404292	1	7475
7952	380662404292	1	7438
8123	0506679091	16	8121
8125	12312312	1	8124
8127	0502083915	1	8126
8128	0502083915	16	8126
7960	0662404292	1	7953
8050	5671313	1	8036
7965	380662404292	1	7477
7966	2423423423	1	7477
7972	02	1	7971
7973	03	1	7971
7975	1231231	16	7974
8051	04412312312	1	8036
7893	380662404292	1	7473
7894	0445648237	16	7473
7895	380662404292	26	7473
7897	380662404292	1	7896
7899	3804412	1	7898
8052	242234234	1	8036
8137	112233	1	7755
8138	380662404292	1	7755
8142	2424242	1	8139
8145	1111111	1	8143
\.


--
-- Name: ani_phones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anicrm
--

SELECT pg_catalog.setval('ani_phones_id_seq', 1, false);


--
-- Name: ani_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_contacts
    ADD CONSTRAINT ani_contacts_pkey PRIMARY KEY (id);


--
-- Name: ani_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_emails
    ADD CONSTRAINT ani_emails_pkey PRIMARY KEY (id);


--
-- Name: ani_files_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_files
    ADD CONSTRAINT ani_files_pkey PRIMARY KEY (id);


--
-- Name: ani_media_types_id_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_media_types
    ADD CONSTRAINT ani_media_types_id_pkey PRIMARY KEY (id);


--
-- Name: ani_messengers_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_messengers
    ADD CONSTRAINT ani_messengers_pkey PRIMARY KEY (id);


--
-- Name: phones_pkey; Type: CONSTRAINT; Schema: public; Owner: anicrm; Tablespace: 
--

ALTER TABLE ONLY ani_phones
    ADD CONSTRAINT phones_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

